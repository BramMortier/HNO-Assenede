-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_sbsiyccjnupznylgxmkdzzxrjfzygkniwzgr` (`primaryOwnerId`),
  CONSTRAINT `fk_sbsiyccjnupznylgxmkdzzxrjfzygkniwzgr` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_trodekstctrrpdpptclmrfxcezcutipvxmuh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gzgipkerkkfygrftxoewrjuwiubuoaodnzmr` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_xgzvvbkvflpjtnvzkxtfmctricriwxisbbty` (`dateRead`),
  KEY `fk_lqspudqztfhwmlmgravgfivisaorkjbumdmc` (`pluginId`),
  CONSTRAINT `fk_lqspudqztfhwmlmgravgfivisaorkjbumdmc` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tdgsmlgbygjeznnlsapjdeouozsszdilbmcl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_avluzaywaolmtqzpflatxqexqgkishlrapix` (`sessionId`,`volumeId`),
  KEY `idx_fpmuznzjuvqcpbmgzxncqchgsebybdlublqw` (`volumeId`),
  CONSTRAINT `fk_gtcarieclevruyssanwdeziadfyyucftjvws` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ynfddkalwkhhrzutqdxgjjzjbsuizmuygrdq` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rpudzapwcsszpjuqpbnvbvmtngfgpvvyjyuu` (`filename`,`folderId`),
  KEY `idx_aojodzrhesbphvldpkrhichxgpivonwbfghw` (`folderId`),
  KEY `idx_votofiikxaieruzhjcljgicqtrxmagxsakcs` (`volumeId`),
  KEY `fk_ayvznhqizlnvygxunkhxwuqltkkxpucwzfsp` (`uploaderId`),
  CONSTRAINT `fk_ayvznhqizlnvygxunkhxwuqltkkxpucwzfsp` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_idvldfjrnmejdoranydwcvszcdvkwvfvccxh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iithiiejpjszmhapkfspdegrvjvbedqqbebb` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wayrfazwsrhuhobuoavhfefytdndatnitosf` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_ugjfajvizeyqnvhxzbwezucoywyroqzjmebn` (`siteId`),
  CONSTRAINT `fk_lphemvsbeirdrgzzywgwxdptoaziwxatmwwo` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ugjfajvizeyqnvhxzbwezucoywyroqzjmebn` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `oldTimestamp` int unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vwaiffsqrrgymgfhguuximglatyqibrwdxob` (`userId`),
  CONSTRAINT `fk_vwaiffsqrrgymgfhguuximglatyqibrwdxob` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `bulkopevents`
--

DROP TABLE IF EXISTS `bulkopevents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bulkopevents` (
  `key` char(10) NOT NULL,
  `senderClass` varchar(255) NOT NULL,
  `eventName` varchar(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`key`,`senderClass`,`eventName`),
  KEY `idx_hsqbloubcyizfcfywdyzinlnxcvqwvposhfi` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kbxllztbbneysklvnrhpkoxiyrewcwuhlwlh` (`groupId`),
  KEY `fk_fbxfjwnumzrrscrovamvlnfekqbecpfuisrg` (`parentId`),
  CONSTRAINT `fk_drzbsmwlmfohfbnkgjvjxnodfnzkmoiauitd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fbxfjwnumzrrscrovamvlnfekqbecpfuisrg` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_hrqxvfpzhacpvkkwbzeyiyvtsleyncgacrto` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zxiegeghfuibajwlrkspybesepxbjpdephce` (`name`),
  KEY `idx_qwsqpchyaxwjzngajzojlhnsosslznglhedc` (`handle`),
  KEY `idx_zbudaufssvwjsaemibaonmdhqlcjfgugafbi` (`structureId`),
  KEY `idx_zxqxojgkuuuzdzozyptdskwiemsimsualiwq` (`fieldLayoutId`),
  KEY `idx_jaxjdeocjaaypugphofpmusaejwtxiaicumy` (`dateDeleted`),
  CONSTRAINT `fk_clxqibfazrxwalhfsyxnfxfvtrylzhgcggok` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tpehlmgcgbcjdgoxkirxdmdamdmzhtnrprpj` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qmguiqudvrghasulyltoiwenzhqqlorzgmgt` (`groupId`,`siteId`),
  KEY `idx_tigqwjtvsgbjcmydbhlzqcifmcfhrcvviqmz` (`siteId`),
  CONSTRAINT `fk_vamadsizcqobnedntofuxqmsmxkegzavqtjr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zhkiqjorffjmlpmfjrmrnmsvvgpscyltpqvh` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_kdfcayywqahnztxchvwqgkkcphgigausfgtl` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_sjuuaykxlgkowqrrqvbbfeacsjdeufaybvfe` (`siteId`),
  KEY `fk_enyliuluxvowtfkuvqrjggdikjysbkdsapia` (`userId`),
  CONSTRAINT `fk_bbrmsyxupavjlmqalssiwqhzutnebjbhcwff` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_enyliuluxvowtfkuvqrjggdikjysbkdsapia` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_sjuuaykxlgkowqrrqvbbfeacsjdeufaybvfe` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_xfvmuslplbcqlwwjyxdvyyzgfitlozghzmbp` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_braonwoeusdojrcuenznbtclsxcavjhnasqt` (`siteId`),
  KEY `fk_hgxnbjgdsollctknlhnhviggholyypwgwgyt` (`fieldId`),
  KEY `fk_btdkywgshrdtgpfwmnywwdmrdqmsvbselbhw` (`userId`),
  CONSTRAINT `fk_braonwoeusdojrcuenznbtclsxcavjhnasqt` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_btdkywgshrdtgpfwmnywwdmrdqmsvbselbhw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_hgxnbjgdsollctknlhnhviggholyypwgwgyt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wsgxzerjngjrimlhnbayluqpyrxeixlgouob` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_vbzgujpaoskqubqoxssngmcurufkyltgfmkl` (`userId`),
  CONSTRAINT `fk_vbzgujpaoskqubqoxssngmcurufkyltgfmkl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_apytjcjtnqxtowhthnssbvledtoeipqemsex` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_mrgbodgvhaodnlvnxwxwmkjvhcaobysmrrgf` (`creatorId`,`provisional`),
  KEY `idx_fcdldyapauksamxuvvxfggbvuewlipsnprer` (`saved`),
  KEY `fk_erqcanzkcrqaqnfzyutqzfezeghsdletfqby` (`canonicalId`),
  CONSTRAINT `fk_erqcanzkcrqaqnfzyutqzfezeghsdletfqby` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zsmsmzozmjbttahfzkguumvfffcauhivcomy` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_lytcmelxjnjaaxxckesphnyjgnahwmepiauu` (`elementId`,`timestamp`,`userId`),
  KEY `fk_xhdxetghiofhwugcejgcxihrrvodbcljzdzv` (`userId`),
  KEY `fk_mqraudgexupsnlevvyivvpmhvifmdwzmvwev` (`siteId`),
  KEY `fk_jazctnwdmcjrasxpvvjlktlihghabpypyric` (`draftId`),
  CONSTRAINT `fk_jazctnwdmcjrasxpvvjlktlihghabpypyric` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_khhfzifdqkhaxdbmtrmbofakqdswhppildyx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mqraudgexupsnlevvyivvpmhvifmdwzmvwev` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xhdxetghiofhwugcejgcxihrrvodbcljzdzv` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wfqvekecysxscgwjzqsgkpzgjmpxegdvixmc` (`dateDeleted`),
  KEY `idx_zxltqqsselpzejslyzbellzdqlnttyrplzna` (`fieldLayoutId`),
  KEY `idx_cufexqgoyghzkjeqhiwrdedujkcexonnfmzc` (`type`),
  KEY `idx_oqhyyihfugtdmaxbowkykebhihpnvkwpcgcn` (`enabled`),
  KEY `idx_mregmbuvqznszsgmxyjixobhmavgajpijvla` (`canonicalId`),
  KEY `idx_vbtlabkcihzayftfwzogvbcxwudhqacshzvr` (`archived`,`dateCreated`),
  KEY `idx_dhsvcwkrxzkqzvkclxljqvmhjvqenxyhjyld` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_qemqndzkaongzvoalhmpiubnhjlcrbbzeleh` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_lpjtqrfjeapdvvlzkyyenbqwoczcjvnfkaom` (`draftId`),
  KEY `fk_cskoblcwhezywadnbhmdzjrshnrpuokekeyp` (`revisionId`),
  CONSTRAINT `fk_cskoblcwhezywadnbhmdzjrshnrpuokekeyp` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lpjtqrfjeapdvvlzkyyenbqwoczcjvnfkaom` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_prheqnjkissoaejschdogyyxyewnzzjtaoog` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xrtmfypipmaqesrlvdyldetsoghnhxpmiwbh` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_gffaplnoynsmgwgwcelcsbbkqdbinjcjithl` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_ldkwvvzfhcqdfucxxggsqkyzeohqtsiwpeve` (`ownerId`),
  CONSTRAINT `fk_ldkwvvzfhcqdfucxxggsqkyzeohqtsiwpeve` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xqzrlnmiwoldumusxojymlxfvcgjpnslybmv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pefuxtewipwdltlzwzpjdgdzymovcruychgr` (`elementId`,`siteId`),
  KEY `idx_pppvdgfjbxyldxjafdrstuvantutytwbdoyg` (`siteId`),
  KEY `idx_xjqvnjetxwlqkuzabvjxuqgswhvtgovmozpf` (`title`,`siteId`),
  KEY `idx_tqpugtcsyatthbgkyzyuyrvdfddshaadxybj` (`slug`,`siteId`),
  KEY `idx_vznpstkavnhxipuonkjtnfpkedcjtnljaicw` (`enabled`),
  KEY `idx_jybwcjrnxjibnofjyheyfpvzavuohqioeokw` (`uri`,`siteId`),
  CONSTRAINT `fk_dvxttapdesrwtludfzgqhyyhozqbtuaqmahy` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rufawpboytyiawhnyaqiywjjxqhvjfswaymf` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `status` enum('live','pending','expired') NOT NULL DEFAULT 'live',
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `deletedWithSection` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ofzjzqqknquymzjvsucsyqhgnpkryduovebd` (`postDate`),
  KEY `idx_ebhxantcgnjtcihroyxymhnqharafdronfzs` (`expiryDate`),
  KEY `idx_ignooobvrmongeuycaqevbmiugbvxfbrkosh` (`sectionId`),
  KEY `idx_roxhpzdbiqzbmyjzwrdzowdtjddfjbpwqdjm` (`typeId`),
  KEY `idx_mmthyzdxuzoaeszaitcycluyhblxzzjfgqda` (`primaryOwnerId`),
  KEY `idx_ssjroshezfshzktfgyfbygkjxqjujtjuzmjf` (`fieldId`),
  KEY `fk_fbszlhqrqrjmpsrqpoiorlxytyonjovkecvh` (`parentId`),
  KEY `idx_wrbrqxdfmftdodvdciidpttdixpdenrxvgdf` (`status`),
  CONSTRAINT `fk_cylwahabchefflobhaoccmppqffpdpavkwbz` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fbszlhqrqrjmpsrqpoiorlxytyonjovkecvh` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_tczhshzovlqutzmufofnrcltbapfexnxgkys` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdeirzehnxktcxuenfzvlboaejuhiglyyshl` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xlweyrmgpngvmlmxdfmsxyugjlhtjtkcvniq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xnlntschlpecnfnmwqdpdrdfnxehbfsbcppf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_eqfrmtvyszhgnwqtsuyvmgzwgsfnzzkmrdgs` (`authorId`),
  KEY `idx_zytkxjqrgwqkysrqggsxbahprravheapqglc` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_fsaukhzrmvnfdfcjqwtngxblxwcfyodpktvi` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kpohonrceftzzhanqitskeothwqlqnietewi` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mdqmgyztncxurhxrgqxopqkpjremokzxofjg` (`fieldLayoutId`),
  KEY `idx_buyrsvodwajnvzxmupkjhmljyqxggrxrbaes` (`dateDeleted`),
  CONSTRAINT `fk_zzabmbunemqegaooyglrjgnnsafqmzvuvuxx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_seftlmcepmylvzaeqkpwvupmhwlrhxhbdodz` (`dateDeleted`),
  KEY `idx_erivvktqcxadhimevyhmroglzxgecphcdelc` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ukdxiqmdmrlxsjhddvsrpwkkhjmwzmewshqr` (`handle`,`context`),
  KEY `idx_qbrhwihscrtfxbvzzsnannomayhashfgligo` (`context`),
  KEY `idx_rpjllrnozkaubvzglnbtbbanvveyihfwbnah` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pjrrdnrgjjtjoiaddgtxofafpclfyljaoikf` (`name`),
  KEY `idx_ykuycswxmuulwwxrqqjoshwgzzzltxgfgbbk` (`handle`),
  KEY `idx_oudrvsqemtxzqleraupjaqyvmtjfrdurkrll` (`fieldLayoutId`),
  KEY `idx_ouxtqxbkvnkjtuepjajvgvrsploiyjojduqi` (`sortOrder`),
  CONSTRAINT `fk_nrmyudknjfgomascadgpnebrigxshvsjzcsq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xwcdnzslfvrpxqgdobwjejsyrgoteybrvqdz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aujtisdpdbgpkyfcarlswvsdgxsnurrranbs` (`accessToken`),
  UNIQUE KEY `idx_pcnrqdmptxkfaqkygvxkhtqgzogtiasvyadj` (`name`),
  KEY `fk_ynvieweahtqoqinpctgipetsaoeatrxgbghj` (`schemaId`),
  CONSTRAINT `fk_ynvieweahtqoqinpctgipetsaoeatrxgbghj` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uhrekckabmzpwvijvygiqcllxipdvxedlbui` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_adxbfjliiawoyusetdjywwnvyvpqlseqwrpw` (`name`),
  KEY `idx_lezfhbtgplfkwjjnzkcnaajkbcoowjlooskf` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nxexzreayapjuiwbouybozgazcjtxxsmzkmh` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ncxloybyfpltuqofioofijnhiuoqwodpcsht` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_dlymqlmieoaruufrqmqkflzfwlsrrccktcgp` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_ujceqsjotkswfslfmfoczggxekapmdgvjrfr` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=476 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nlbkpymgidesmyucqeghneinkhlozebmzkqh` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_dlklclzkkaywzyzecqyajxpmbzdlmmbqmhfh` (`sourceId`),
  KEY `idx_wcjthqxxzrdydobhjjlfirayaksetbajjtdd` (`targetId`),
  KEY `idx_rnvjfonegwdtggerqiljjxtipkxiatjtxnrz` (`sourceSiteId`),
  CONSTRAINT `fk_gfnecczapfgtanjggvvoipwpazzvhrpyhzgb` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sldndupkgiinuoxgfrwpbephlqokvnqtfjse` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tfpuznjpjnetluydirkvddmmiuvhssglanvp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_flqvbqqewpitkrafugdxixnyyxtnnsgcfntk` (`canonicalId`,`num`),
  KEY `fk_wmrjariivwycaunnlqjyeyqkxwngmlwuhfos` (`creatorId`),
  CONSTRAINT `fk_bnyszxuyeqtjabwwbxrvqytalkpetcklkmry` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wmrjariivwycaunnlqjyeyqkxwngmlwuhfos` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_wbwblzmmjtfxqgltbxmoswwglgbefmjlyfvo` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindexqueue`
--

DROP TABLE IF EXISTS `searchindexqueue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `reserved` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_exoxhgjwocyiofnnjlhjwdeueirevutzvsrx` (`elementId`,`siteId`,`reserved`),
  CONSTRAINT `fk_xpjdwmpicbgucdljaknpfgmxvokozesjnjmt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindexqueue_fields`
--

DROP TABLE IF EXISTS `searchindexqueue_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindexqueue_fields` (
  `jobId` int NOT NULL,
  `fieldHandle` varchar(255) NOT NULL,
  PRIMARY KEY (`jobId`,`fieldHandle`),
  UNIQUE KEY `idx_nfumrukwcdiugkaufmsxfkwwrzyxbxspshwe` (`jobId`,`fieldHandle`),
  CONSTRAINT `fk_rflhzjvwgyvexlkofgwcruldnealegltmvby` FOREIGN KEY (`jobId`) REFERENCES `searchindexqueue` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned DEFAULT NULL,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_owefhdcebssglehmdfesdcktfbrnzztpsxzz` (`handle`),
  KEY `idx_wswdxczswqyngqzaipgqrobdoxhlbfcqmaiq` (`name`),
  KEY `idx_tmbidmqrhyueappwbgyfraooehikqnqfxhxv` (`structureId`),
  KEY `idx_zdjodpahxojpzblvxpzlqqlvaifgnylxqnrd` (`dateDeleted`),
  CONSTRAINT `fk_xefzjjbbytlesradxmhafldynawzrcjqpojc` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `handle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_oryhzqhblohaqjqjizuoybihdqctyeqzgbnu` (`typeId`),
  CONSTRAINT `fk_oryhzqhblohaqjqjizuoybihdqctyeqzgbnu` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yuxbubiifbedymyzgwahjphntjrbqpbnagya` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kxjkrunkjgadxjxospfuyqdoiqxbuvnhxter` (`sectionId`,`siteId`),
  KEY `idx_etxqsjclbhgdogxqgjlftsshxlfvwqewwjlb` (`siteId`),
  CONSTRAINT `fk_ebasyemlxzyztnyvmrsxgyvtttxjjcxlpwsm` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_iigmlmxwelnpedlqvrdaoahtklckuooxyqtb` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seo_redirects`
--

DROP TABLE IF EXISTS `seo_redirects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_redirects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `uri` varchar(255) NOT NULL,
  `to` varchar(255) NOT NULL,
  `type` enum('301','302') NOT NULL,
  `siteId` int DEFAULT NULL,
  `order` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seo_sitemap`
--

DROP TABLE IF EXISTS `seo_sitemap`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seo_sitemap` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group` enum('sections','categories','productTypes','customUrls') NOT NULL,
  `url` varchar(255) NOT NULL,
  `frequency` enum('always','hourly','daily','weekly','monthly','yearly','never') NOT NULL,
  `priority` float NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_erwrdepsawogcykgvdbbmcdtcutmrfqzkqhq` (`uid`),
  KEY `idx_ggvmpdyvpknhnqnvwuvvioogtyxkclsbwpcb` (`token`),
  KEY `idx_ukhyyaapjqrxrqqdbvxhpbeuoalgekeqcisj` (`dateUpdated`),
  KEY `idx_bwtuyyczyybcgldogjwiisetdztcotpugnsk` (`userId`),
  CONSTRAINT `fk_vecsxyatuuukfjbzruyaxyfvdgycuxpspvtc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ddrosvduttnrdftsbjiynphwbkbybrcqtzpk` (`userId`,`message`),
  CONSTRAINT `fk_tzvslchjwxepulllysmuwymbxkociigdcqhn` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_moxpvzateiphurgajaygnlwanzosobkcmclp` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_igpkbhmyxcfghsickmyotcrjonymyzmbybgt` (`dateDeleted`),
  KEY `idx_vzoufbibbxgsjngefvgriroqccrafqozxqcp` (`handle`),
  KEY `idx_yqtynwsuqkxeazsceruhmqbwjfvgpmkpfnqt` (`sortOrder`),
  KEY `fk_cmsufrtfsjjmodparnalojeerxbaaxmzkwkx` (`groupId`),
  CONSTRAINT `fk_cmsufrtfsjjmodparnalojeerxbaaxmzkwkx` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sso_identities`
--

DROP TABLE IF EXISTS `sso_identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sso_identities` (
  `provider` varchar(255) NOT NULL,
  `identityId` varchar(255) NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`provider`,`identityId`,`userId`),
  KEY `fk_nvnzgbuvxgwgaotjkaiozlnuivqmlflxudvm` (`userId`),
  CONSTRAINT `fk_nvnzgbuvxgwgaotjkaiozlnuivqmlflxudvm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xmnmfomfchbjkneipezwjgftcoacjvgvxwhi` (`structureId`,`elementId`),
  KEY `idx_hwmtqmegycfnuwxumnkqwyotjcuqrwkhbfew` (`root`),
  KEY `idx_zplkratomepgwntsqhtjrzedijxyjyhuerta` (`lft`),
  KEY `idx_uqimaygyenacfersstwvlfxopxiplniaiuos` (`rgt`),
  KEY `idx_bgzedeinjhsckafmqnghumyaczkndicjkolh` (`level`),
  KEY `idx_jsjdyvxydzsijmcjivyrsqfxpwvkdbbqmuto` (`elementId`),
  CONSTRAINT `fk_xmzwmejlnaxyaqdxcitzozcmkjheubdvhwqa` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bqvmqqwbfxahgibtgngmtgfuerltijbktpsa` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmukyusjultleskygbaateofzlpmigigtuoo` (`key`,`language`),
  KEY `idx_oabzhxuvublkxwmrvowrrzjmruwlastgcgsd` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gvynxcjgdajayeejzhouluxqlfwgrdhomumb` (`name`),
  KEY `idx_pknozbjzhpmshrdlwtixbrabclfrqcsozgwa` (`handle`),
  KEY `idx_oufwspsticemfclrgshdicjcdfzrlkycmzng` (`dateDeleted`),
  KEY `fk_vuoyvirmvaowvqpldxnfiekhsfpwjvgtpifq` (`fieldLayoutId`),
  CONSTRAINT `fk_vuoyvirmvaowvqpldxnfiekhsfpwjvgtpifq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cvavgkezzmoetjxiylccgylfvxewjrhwjkiu` (`groupId`),
  CONSTRAINT `fk_iwspgfvjssyhyvuorblbtcfivrdmcodsqoek` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zcgolrwxlrfaevaemumemwdnxpcddwcobbil` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lqfwyyvtxnbsggtpctbxeixwponxmntcjitn` (`token`),
  KEY `idx_nrqajysdbwlwejvzthmbubepmrzvbdfzcorh` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_abmysbprfpqigesuytrqrtesnkmhsysmcgmh` (`handle`),
  KEY `idx_bryzljyztpbygubuscybzjkuxhithsoykhxe` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uugpcvgpnwrhnljmubnqxwxadbiekbltfuio` (`groupId`,`userId`),
  KEY `idx_lyihejjudaxfnpmjkrmjvyltzoilongjtogx` (`userId`),
  CONSTRAINT `fk_iyiklekdojnztbwbnvoffkelpmybvepoeedf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vzgjwdnphqevggqgdpdorsobnolfhhgiljuq` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_olujfoqtrqgbdacafncrwzgymjeudqutxvqg` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bdkpreibnwfwrpgzgiatwwzugssjeoexhbri` (`permissionId`,`groupId`),
  KEY `idx_rnxxnbpykymujmlwuuitosmmupkvlfjafhtt` (`groupId`),
  CONSTRAINT `fk_gvxjnlgpawiyatavxzdligrlwqtswmagbjpf` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mjxesthmdkfsogpgwxzvgbhnsskrnniasmgv` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rkmpjueajajfjxgqpcirpenwmcjxwtmhgjoe` (`permissionId`,`userId`),
  KEY `idx_jtoohbzrxcndcqitnwxcjyradnxhbeiwbgxn` (`userId`),
  CONSTRAINT `fk_jyynhctimauhrjnsphqeogbhtacyszyqgdyg` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zxghzctdcbcykwvlutnppydsthalhecotlvw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_jolujrkrbfxcimnaijtzzdnqwermiwnqghkz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `affiliatedSiteId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nmmjiknboxjfyjvtmtbzewpmfkxechgxmmgo` (`active`),
  KEY `idx_abiwplciovfqwrldazvdknwzcqztbvmwwsvd` (`locked`),
  KEY `idx_jxuzojqhhxhxyxdgrtldmoyielqtjoktukbc` (`pending`),
  KEY `idx_faqnbvvshcdsbkexwwedhgfkehfhlskxicvf` (`suspended`),
  KEY `idx_zakmtnsqqasotfftwjytqlonwbyqoqydsrcn` (`verificationCode`),
  KEY `idx_aqcvhpmirntulcnrfwoyeyzegkyuzghvaokq` (`email`),
  KEY `idx_ijrepsplksgqxnfekdqfqcupffxktluulgfx` (`username`),
  KEY `fk_xrhdpfdsmdagktbyoaumblqghzygkaajeeyd` (`photoId`),
  KEY `fk_zzjxehpcianagsdgxxajjftbpygajtcumbod` (`affiliatedSiteId`),
  CONSTRAINT `fk_xlntfgkmgtfqupghascgblnwklejrtzbqywe` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xrhdpfdsmdagktbyoaumblqghzygkaajeeyd` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zzjxehpcianagsdgxxajjftbpygajtcumbod` FOREIGN KEY (`affiliatedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_psudaiwquxmzyglntkfmzwsendbnsyoorydx` (`name`,`parentId`,`volumeId`),
  KEY `idx_wfrskndbmxkyesyukfrlxwckxgopoirhqsvn` (`parentId`),
  KEY `idx_usoffaowgnvxwqnazzmtuhvopacksdfdplal` (`volumeId`),
  CONSTRAINT `fk_fhgokpbvmzzsbazdqcfcnyzciaoogmejpisp` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qkjnaafznzilcblpxpefqsrppfzdmdwwnnhe` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pddwqrtxzbxparlnjugkorsmzkxqnjaquvhc` (`name`),
  KEY `idx_mcfwsnrllifucqmazlmsisaigmcpardvvrbf` (`handle`),
  KEY `idx_eqsikjshbdnjmwzaffohvfwtutsfumagjbvt` (`fieldLayoutId`),
  KEY `idx_nqhgjstymdzlynzmxvsimoapdbbjlhcytkcm` (`dateDeleted`),
  CONSTRAINT `fk_ncfqlbcczodytkvcokyqwmgvzekiavsxbbfm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_ptlspmlegrchrwozrgwwgvpovimxqcddlybx` (`userId`),
  CONSTRAINT `fk_ptlspmlegrchrwozrgwwgvpovimxqcddlybx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wtxszejlyghqolecrodiljhpivfmnxlmddhx` (`userId`),
  CONSTRAINT `fk_tfpvepbnomjewjqhpzdvxytvfplfkynndhay` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-17 10:17:24
-- MySQL dump 10.13  Distrib 8.0.40, for Linux (aarch64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets` VALUES (87,1,1,1,'person.jpg','image',NULL,256,256,8165,NULL,0,0,'2025-03-14 11:37:21','2025-03-14 11:37:21','2025-03-14 11:37:21');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `assets_sites` VALUES (87,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `bulkopevents`
--

LOCK TABLES `bulkopevents` WRITE;
/*!40000 ALTER TABLE `bulkopevents` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `bulkopevents` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (1,1,'lastPasswordChangeDate','2025-06-17 07:55:21',0,NULL),(1,1,'password','2025-06-17 07:55:21',0,NULL),(4,1,'slug','2025-03-14 11:40:04',0,1),(15,1,'title','2024-11-22 22:39:03',0,1),(36,1,'title','2025-03-14 11:31:53',0,1),(74,1,'postDate','2024-12-20 15:58:13',0,1),(74,1,'title','2024-12-20 15:58:13',0,1),(75,1,'postDate','2024-12-20 15:57:52',0,1),(75,1,'title','2024-12-20 15:57:52',0,1),(76,1,'postDate','2024-12-20 15:58:11',0,1),(76,1,'title','2024-12-20 15:58:11',0,1),(77,1,'postDate','2025-01-03 12:56:56',0,1),(77,1,'slug','2025-01-03 12:56:56',0,1),(77,1,'title','2025-01-03 12:56:56',0,1),(77,1,'uri','2025-01-03 12:56:56',0,1),(79,1,'postDate','2025-01-03 13:00:24',0,1),(79,1,'slug','2025-01-03 13:00:24',0,1),(79,1,'title','2025-01-03 13:00:24',0,1),(79,1,'uri','2025-01-03 13:00:24',0,1),(81,1,'postDate','2025-01-03 13:00:32',0,1),(81,1,'slug','2025-01-03 13:00:32',0,1),(81,1,'title','2025-01-03 13:00:32',0,1),(81,1,'uri','2025-01-03 13:00:32',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (4,1,12,'7f96e298-8f7d-4fe5-a49d-5cc2f976c676','2025-05-26 08:43:46',0,1),(15,1,3,'c5081a8a-b23c-437a-adf6-b340842dbcb2','2024-11-22 22:26:32',0,1),(15,1,13,'312c1fff-6c1f-46c5-a23a-4d649aa751e7','2024-11-22 22:26:32',0,1),(15,1,18,'b3b33377-65d9-41c7-b967-e9171e5b6232','2024-11-22 22:39:03',0,1),(36,1,3,'c5081a8a-b23c-437a-adf6-b340842dbcb2','2025-03-14 11:31:53',0,1),(36,1,18,'8b093641-00e3-4319-8b67-75a5fb11174b','2024-12-20 15:41:13',0,1),(74,1,2,'40ed50a6-3625-4738-bc83-38cfb5c7856c','2024-12-20 15:57:28',0,1),(74,1,19,'18d1e987-82c9-4983-94e9-d529a8d6525a','2024-12-20 15:57:31',0,1),(74,1,22,'7b6b8d88-d146-4b44-87b7-d226061a4ba2','2024-12-20 15:57:24',0,1),(75,1,2,'4fb1eda8-5465-4a7b-98e6-5b49864eb261','2024-12-20 15:57:45',0,1),(75,1,22,'a3bd6039-d017-40d2-9bab-04c8f6ac8ae6','2024-12-20 15:57:50',0,1),(76,1,2,'4fb1eda8-5465-4a7b-98e6-5b49864eb261','2024-12-20 15:58:05',0,1),(76,1,22,'a3bd6039-d017-40d2-9bab-04c8f6ac8ae6','2024-12-20 15:58:10',0,1),(77,1,1,'29fcd495-2a8f-498b-992c-d481dd7f72f5','2025-01-03 12:56:56',0,1),(79,1,1,'29fcd495-2a8f-498b-992c-d481dd7f72f5','2025-01-03 13:00:24',0,1),(81,1,1,'29fcd495-2a8f-498b-992c-d481dd7f72f5','2025-01-03 13:00:32',0,1),(95,1,23,'a4c0a2a1-4545-44dc-b3c3-a1ddb151aade','2025-05-26 08:43:46',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft',NULL,0,NULL,0),(2,NULL,1,0,'First draft',NULL,0,NULL,0),(3,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elementactivity` VALUES (4,1,1,NULL,'edit','2025-05-26 08:43:46'),(4,1,1,NULL,'save','2025-06-17 08:07:17'),(74,1,1,NULL,'save','2024-12-20 15:58:13'),(75,1,1,NULL,'save','2024-12-20 15:57:52'),(76,1,1,NULL,'save','2024-12-20 15:58:11'),(77,1,1,NULL,'save','2025-01-03 12:56:56'),(79,1,1,NULL,'save','2025-01-03 13:00:24'),(81,1,1,NULL,'save','2025-01-03 13:00:32');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-10-11 09:30:43','2025-06-17 07:55:20',NULL,NULL,NULL,'708cfeea-da30-443e-b0c2-da360909c42e'),(2,NULL,NULL,NULL,4,'craft\\elements\\GlobalSet',1,0,'2024-10-11 14:44:15','2024-12-20 16:02:35',NULL,NULL,NULL,'a67d48bc-e451-47d9-9b4d-11993da85ee2'),(3,NULL,NULL,NULL,5,'craft\\elements\\GlobalSet',1,0,'2024-10-11 14:44:41','2024-12-20 15:54:36',NULL,NULL,NULL,'462faf00-5b99-4cd1-b2ba-9fb0321c0ed3'),(4,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2024-10-11 15:04:45','2025-06-17 08:07:17',NULL,NULL,NULL,'1f96e5f1-9053-46a9-97d2-7a7e1f8878a4'),(5,4,NULL,1,6,'craft\\elements\\Entry',1,0,'2024-10-11 15:04:45','2024-10-11 15:04:45',NULL,NULL,NULL,'651aa844-b35c-42cc-96cb-220112a1139a'),(6,4,NULL,2,6,'craft\\elements\\Entry',1,0,'2024-10-11 15:05:55','2024-10-11 15:05:55',NULL,NULL,NULL,'7f341dd2-229b-4875-b4dc-6ec9016adf3f'),(7,4,NULL,3,6,'craft\\elements\\Entry',1,0,'2024-10-29 15:31:53','2024-10-29 15:31:53',NULL,NULL,NULL,'ed4485e3-12ca-40d4-9466-8c72783c198e'),(8,NULL,1,NULL,3,'craft\\elements\\Entry',1,0,'2024-11-13 14:20:14','2024-11-13 14:20:14',NULL,'2024-11-22 21:35:57',NULL,'11e3bbc1-a680-49e6-ab01-46705f73291d'),(9,NULL,2,NULL,8,'craft\\elements\\Entry',1,0,'2024-11-13 14:25:58','2024-11-13 14:25:58',NULL,'2024-11-22 21:36:00',NULL,'1820580d-fbfe-42b7-b877-c8bf8db3efe5'),(10,NULL,3,NULL,8,'craft\\elements\\Entry',1,0,'2024-11-13 14:28:56','2024-11-13 14:28:56',NULL,'2024-11-22 21:36:00',NULL,'ca7bc282-2e27-4929-ade7-dbeaf72c90f9'),(15,NULL,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2024-11-22 22:02:43','2024-11-22 22:47:39',NULL,'2024-11-22 22:47:39',NULL,'e35064d9-ec04-4f24-a51a-ffcf87e06794'),(16,4,NULL,4,6,'craft\\elements\\Entry',1,0,'2024-11-22 22:02:43','2024-11-22 22:02:43',NULL,NULL,NULL,'a457727d-bdfe-4d48-8e6d-8ddb4e4e1ab7'),(17,15,NULL,5,10,'craft\\elements\\Entry',1,0,'2024-11-22 22:02:43','2024-11-22 22:02:43',NULL,'2024-11-22 22:47:39',NULL,'f263ef2e-466e-4aff-b7d4-8e1f992c83cd'),(21,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2024-11-22 22:26:32','2024-11-22 22:47:39',NULL,'2024-11-22 22:47:39',1,'9b3a8766-7688-4f97-a4f2-0d07cd3b8e5e'),(22,4,NULL,6,6,'craft\\elements\\Entry',1,0,'2024-11-22 22:26:32','2024-11-22 22:26:32',NULL,NULL,NULL,'108db4e5-7e9b-47f7-a8a4-359921b87908'),(23,15,NULL,7,10,'craft\\elements\\Entry',1,0,'2024-11-22 22:26:32','2024-11-22 22:26:32',NULL,'2024-11-22 22:47:39',NULL,'df4a1fe3-68e3-4a59-9c0e-9e0f02ac376d'),(24,21,NULL,8,9,'craft\\elements\\Entry',1,0,'2024-11-22 22:26:32','2024-11-22 22:26:32',NULL,'2024-11-22 22:47:39',NULL,'c30506a5-fa82-4982-8ba5-12798eac398e'),(28,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2024-11-22 22:39:03','2024-11-22 22:47:39',NULL,'2024-11-22 22:47:39',1,'42421514-499c-4100-adfe-641485156bba'),(29,4,NULL,9,6,'craft\\elements\\Entry',1,0,'2024-11-22 22:39:03','2024-11-22 22:39:03',NULL,NULL,NULL,'d5fba34d-f680-48f8-be1d-4b7fcf4c47c0'),(30,15,NULL,10,10,'craft\\elements\\Entry',1,0,'2024-11-22 22:39:03','2024-11-22 22:39:03',NULL,'2024-11-22 22:47:39',NULL,'9914939c-42f0-41af-9d52-daf25b29c3c2'),(31,28,NULL,11,9,'craft\\elements\\Entry',1,0,'2024-11-22 22:39:03','2024-11-22 22:39:03',NULL,'2024-11-22 22:47:39',NULL,'b91f13f0-c18d-4ed6-9865-255a01417562'),(33,4,NULL,12,6,'craft\\elements\\Entry',1,0,'2024-11-22 22:47:39','2024-11-22 22:47:39',NULL,NULL,NULL,'7add40c1-1db2-438d-ad21-d9304134eae5'),(36,NULL,NULL,NULL,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:07:45','2025-03-14 11:31:53',NULL,NULL,NULL,'8522882a-1709-4a65-8782-f0b487826672'),(37,4,NULL,13,6,'craft\\elements\\Entry',1,0,'2024-12-20 09:07:45','2024-12-20 09:07:45',NULL,NULL,NULL,'5433ab88-9cb4-42e2-8c68-d772271728a9'),(38,36,NULL,14,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:07:45','2024-12-20 09:07:45',NULL,NULL,NULL,'f3b1ff4d-078b-45ba-9241-c37b94dfb666'),(41,4,NULL,15,6,'craft\\elements\\Entry',1,0,'2024-12-20 09:18:23','2024-12-20 09:18:23',NULL,NULL,NULL,'ac04ca65-bcd0-45b2-aa7d-5303cf750d08'),(42,36,NULL,16,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:18:23','2024-12-20 09:18:23',NULL,NULL,NULL,'87d3b225-a4cc-45f2-9c11-15610fee6f52'),(45,4,NULL,17,6,'craft\\elements\\Entry',1,0,'2024-12-20 09:20:51','2024-12-20 09:20:51',NULL,NULL,NULL,'0428f8d1-b7b4-4485-84e3-6b3988c8472c'),(46,36,NULL,18,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:20:51','2024-12-20 09:20:51',NULL,NULL,NULL,'005f2884-facc-4dc9-81fe-9deaac6ca39f'),(49,4,NULL,19,6,'craft\\elements\\Entry',1,0,'2024-12-20 09:21:51','2024-12-20 09:21:51',NULL,NULL,NULL,'d98a19f0-12e4-4d85-836a-8f46b86b8718'),(50,36,NULL,20,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:21:51','2024-12-20 09:21:51',NULL,NULL,NULL,'eaeceebc-784e-4d50-b34d-aebe9b1c0010'),(53,4,NULL,21,6,'craft\\elements\\Entry',1,0,'2024-12-20 09:45:11','2024-12-20 09:45:11',NULL,NULL,NULL,'4acbe398-9a0c-4487-b771-e40893d0917d'),(54,36,NULL,22,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:45:11','2024-12-20 09:45:11',NULL,NULL,NULL,'9b2c75e6-0a6e-4274-900f-c8221920e110'),(57,4,NULL,23,6,'craft\\elements\\Entry',1,0,'2024-12-20 09:58:32','2024-12-20 09:58:32',NULL,NULL,NULL,'4e68498e-c902-4354-abcb-fb4736be4413'),(58,36,NULL,24,10,'craft\\elements\\Entry',1,0,'2024-12-20 09:58:32','2024-12-20 09:58:32',NULL,NULL,NULL,'f0009306-9467-416a-aa5b-f00814693e07'),(61,4,NULL,25,6,'craft\\elements\\Entry',1,0,'2024-12-20 10:09:11','2024-12-20 10:09:11',NULL,NULL,NULL,'d24a4ec9-6b02-47ff-b3c5-a504ddff7f7d'),(62,36,NULL,26,10,'craft\\elements\\Entry',1,0,'2024-12-20 10:09:11','2024-12-20 10:09:11',NULL,NULL,NULL,'8dc8a51f-9586-483e-a183-7a2a420e1a65'),(65,4,NULL,27,6,'craft\\elements\\Entry',1,0,'2024-12-20 10:15:55','2024-12-20 10:15:56',NULL,NULL,NULL,'6f4c82f0-d60b-4ec3-9081-26583b88a5a0'),(66,36,NULL,28,10,'craft\\elements\\Entry',1,0,'2024-12-20 10:15:56','2024-12-20 10:15:56',NULL,NULL,NULL,'e55f9e21-4fab-448b-9f2e-5cffaac263f2'),(70,NULL,NULL,NULL,9,'craft\\elements\\Entry',1,0,'2024-12-20 15:41:13','2024-12-20 15:41:13',NULL,NULL,NULL,'2199144d-9c3e-4625-b4b7-61876ab608b5'),(71,4,NULL,29,6,'craft\\elements\\Entry',1,0,'2024-12-20 15:41:13','2024-12-20 15:41:13',NULL,NULL,NULL,'39d33e8b-bc38-4e08-a22e-bcd68a0c7d41'),(72,36,NULL,30,10,'craft\\elements\\Entry',1,0,'2024-12-20 15:41:13','2024-12-20 15:41:13',NULL,NULL,NULL,'d811820a-5fa0-4047-8b28-01c130c9ef32'),(73,70,NULL,31,9,'craft\\elements\\Entry',1,0,'2024-12-20 15:41:13','2024-12-20 15:41:13',NULL,NULL,NULL,'d75f1462-ecaa-4345-b2b6-835914600544'),(74,NULL,NULL,NULL,13,'craft\\elements\\Entry',1,0,'2024-12-20 15:57:16','2024-12-20 16:02:34',NULL,'2024-12-20 16:02:34',NULL,'3b4a32f6-f556-463b-84bf-d3ce47daab7a'),(75,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2024-12-20 15:57:31','2024-12-20 16:02:34',NULL,'2024-12-20 16:02:34',1,'2c4a268e-5b35-42fc-a928-c83b04d84f06'),(76,NULL,NULL,NULL,11,'craft\\elements\\Entry',1,0,'2024-12-20 15:58:01','2024-12-20 16:02:34',NULL,'2024-12-20 16:02:34',1,'ac1d39a1-3526-4382-bfab-79f9708f4de4'),(77,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2025-01-03 12:56:46','2025-01-03 12:56:56',NULL,NULL,NULL,'9b394c40-33ff-481c-bf0b-912140fd282c'),(78,77,NULL,32,6,'craft\\elements\\Entry',1,0,'2025-01-03 12:56:56','2025-01-03 12:56:56',NULL,NULL,NULL,'bf7fb360-515d-41fb-9cfb-451a7bcef64e'),(79,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2025-01-03 13:00:12','2025-01-03 13:00:24',NULL,NULL,NULL,'29f63648-112d-4bc1-b2a9-232d37793849'),(80,79,NULL,33,6,'craft\\elements\\Entry',1,0,'2025-01-03 13:00:24','2025-01-03 13:00:24',NULL,NULL,NULL,'c2d47137-9c09-4371-8ba2-bfb9b9270475'),(81,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2025-01-03 13:00:27','2025-01-03 13:00:32',NULL,NULL,NULL,'3d03c552-ed48-453c-9387-5980343b770a'),(82,81,NULL,34,6,'craft\\elements\\Entry',1,0,'2025-01-03 13:00:32','2025-01-03 13:00:32',NULL,NULL,NULL,'67c5267e-88ec-4472-8322-5f8f95cf0220'),(85,4,NULL,35,6,'craft\\elements\\Entry',1,0,'2025-03-14 11:31:53','2025-03-14 11:31:53',NULL,NULL,NULL,'5a066550-1835-46d6-9dae-6c995b3540e2'),(86,36,NULL,36,10,'craft\\elements\\Entry',1,0,'2025-03-14 11:31:53','2025-03-14 11:31:53',NULL,NULL,NULL,'7f0a6698-c883-4d4e-972c-b0b5bf9c4072'),(87,NULL,NULL,NULL,1,'craft\\elements\\Asset',1,0,'2025-03-14 11:37:21','2025-03-14 11:38:59',NULL,'2025-03-14 11:38:59',NULL,'030dcb32-24b1-4b61-85f6-756047e7d431'),(89,4,NULL,37,6,'craft\\elements\\Entry',1,0,'2025-03-14 11:39:35','2025-03-14 11:39:35',NULL,NULL,NULL,'3559a704-173e-4411-9b43-5cacbb3c065b'),(91,4,NULL,38,6,'craft\\elements\\Entry',1,0,'2025-03-14 11:39:52','2025-03-14 11:39:53',NULL,NULL,NULL,'b204ec4b-beac-46a9-80ba-4ea22f23cc6d'),(92,4,NULL,39,6,'craft\\elements\\Entry',1,0,'2025-03-14 11:40:04','2025-03-14 11:40:04',NULL,NULL,NULL,'e10804f3-82c6-47d9-9e5d-c00b82189c85'),(95,NULL,NULL,NULL,12,'craft\\elements\\Entry',1,0,'2025-05-26 08:39:52','2025-05-26 08:43:46',NULL,NULL,NULL,'b63f3fd4-7496-4551-b9ef-24dfd372d102'),(96,4,NULL,40,6,'craft\\elements\\Entry',1,0,'2025-05-26 08:39:52','2025-05-26 08:39:52',NULL,NULL,NULL,'754dabd9-cf2a-493f-84c9-21bc36db864a'),(97,95,NULL,41,12,'craft\\elements\\Entry',1,0,'2025-05-26 08:39:52','2025-05-26 08:39:52',NULL,NULL,NULL,'ac373acd-64e3-4c7d-a95f-7de700de8867'),(98,4,NULL,42,6,'craft\\elements\\Entry',1,0,'2025-05-26 08:41:47','2025-05-26 08:41:47',NULL,NULL,NULL,'d81ad764-db15-43c2-b84c-1fcb6219ae26'),(99,4,NULL,43,6,'craft\\elements\\Entry',1,0,'2025-05-26 08:42:07','2025-05-26 08:42:07',NULL,NULL,NULL,'1837b64f-342d-4439-90de-5ca56e28e6fa'),(102,4,NULL,44,6,'craft\\elements\\Entry',1,0,'2025-05-26 08:43:46','2025-05-26 08:43:46',NULL,NULL,NULL,'8a4b1556-541d-4d3a-9c81-24f6f3ae6e36'),(103,95,NULL,45,12,'craft\\elements\\Entry',1,0,'2025-05-26 08:43:46','2025-05-26 08:43:46',NULL,NULL,NULL,'267aa7ce-89bf-4590-8a9d-adddd5549a54'),(104,4,NULL,46,6,'craft\\elements\\Entry',1,0,'2025-05-26 08:46:42','2025-05-26 08:46:42',NULL,NULL,NULL,'21cdaf38-0a85-448d-82a8-e389792e3b34'),(105,4,NULL,47,6,'craft\\elements\\Entry',1,0,'2025-06-17 08:07:17','2025-06-17 08:07:17',NULL,NULL,NULL,'4e0afc7b-d242-4038-bc87-d0ee2c0567e2');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_owners` VALUES (8,2,1),(9,2,1),(10,2,2),(15,4,1),(17,16,1),(21,15,1),(23,22,1),(24,23,1),(24,30,1),(28,15,2),(30,29,1),(31,30,2),(36,4,2),(38,37,1),(42,41,1),(46,45,1),(50,49,1),(54,53,1),(58,57,1),(62,61,1),(66,65,1),(70,36,1),(72,71,1),(73,72,1),(74,2,1),(75,74,1),(76,74,2),(86,85,1),(86,89,1),(86,91,1),(86,92,1),(86,96,2),(86,98,2),(86,99,2),(86,102,2),(86,104,2),(86,105,2),(95,4,1),(97,96,1),(97,98,1),(97,99,1),(103,102,1),(103,104,1),(103,105,1);
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-10-11 09:30:43','2024-10-11 09:30:43','a67fb191-54c1-4d1c-9325-67ef46f8be8b'),(2,2,1,NULL,NULL,NULL,NULL,1,'2024-10-11 14:44:15','2024-10-11 14:44:15','86b37b4c-23e8-4ce0-892f-341f9aa82028'),(3,3,1,NULL,NULL,NULL,NULL,1,'2024-10-11 14:44:41','2024-10-11 14:44:41','ef325481-a8f5-4dc9-b061-028eb0853e44'),(4,4,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-10-11 15:04:45','2025-05-26 08:39:52','a3b4c7eb-0de7-4aa2-9924-6a11072ff757'),(5,5,1,'Home','home','__home__',NULL,1,'2024-10-11 15:04:45','2024-10-11 15:04:45','9631b2c0-1d76-45e9-a170-ade1d0cc9ce5'),(6,6,1,'Home','home','__home__',NULL,1,'2024-10-11 15:05:55','2024-10-11 15:05:55','c28e430c-6f1b-4b4c-9bf4-8a1a32a8167b'),(7,7,1,'Home','home','__home__',NULL,1,'2024-10-29 15:31:53','2024-10-29 15:31:53','0a0f0a61-543f-4a99-b457-5fbd9d1f09d7'),(8,8,1,NULL,'__temp_vrhawgbayppwysuxxzqxfcgaysevlawfqkhm',NULL,'{\"2d8e0d7a-a578-44e5-8821-76b2df26e06f\": \"_self\"}',1,'2024-11-13 14:20:14','2024-11-13 14:20:14','1f5ddb05-750b-4a3a-965d-833c6fe30fdf'),(9,9,1,NULL,'__temp_hedusacfxjvtdemjutkcbwllbwftmarwzmsx',NULL,NULL,1,'2024-11-13 14:25:58','2024-11-13 14:25:58','e1cf151b-b3e3-446b-be33-377e76d6f583'),(10,10,1,NULL,'__temp_rucukrqhglvxrqldmzoclpdyfvpmvlkajdhs',NULL,NULL,1,'2024-11-13 14:28:56','2024-11-13 14:28:56','170d7997-43de-4994-b274-46537ace9bde'),(15,15,1,NULL,'__temp_jqzhbvqvdnhhvabixqsoxumltfomqctslpgf',NULL,'{\"312c1fff-6c1f-46c5-a23a-4d649aa751e7\": \"<p>Test title</p>\", \"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\"}',1,'2024-11-22 22:02:43','2024-11-22 22:26:32','61fbecea-44e7-4d98-a36e-59e0af105fa0'),(16,16,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-11-22 22:02:43','2024-11-22 22:02:43','597db561-2850-4cd6-ba17-729d40ecbe8b'),(17,17,1,NULL,'__temp_jqzhbvqvdnhhvabixqsoxumltfomqctslpgf',NULL,NULL,1,'2024-11-22 22:02:43','2024-11-22 22:02:43','5d59ca5e-4818-4e63-8106-bb56f5575ae7'),(21,21,1,NULL,'__temp_cbjkdgxisfzqiukkfhnhsspdgeinljvxnmfs',NULL,'{\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\": \"c-button-primary\", \"e4a35e4f-b60c-4513-b570-ed9745e7b66b\": {\"type\": \"entry\", \"label\": \"Button\", \"value\": \"{entry:4@1:url}\", \"target\": \"_blank\"}}',1,'2024-11-22 22:26:32','2024-11-22 22:26:32','544ac66d-5528-43b4-b98c-6cc7b02f6c95'),(22,22,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-11-22 22:26:32','2024-11-22 22:26:32','b580d04e-7ef6-43de-92b0-a5eecc764ca3'),(23,23,1,NULL,'__temp_jqzhbvqvdnhhvabixqsoxumltfomqctslpgf',NULL,'{\"312c1fff-6c1f-46c5-a23a-4d649aa751e7\": \"<p>Test title</p>\", \"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\"}',1,'2024-11-22 22:26:32','2024-11-22 22:26:32','01ab72fe-5901-43d2-afbd-5f855d5c0ffb'),(24,24,1,NULL,'__temp_cbjkdgxisfzqiukkfhnhsspdgeinljvxnmfs',NULL,'{\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\": \"c-button-primary\", \"e4a35e4f-b60c-4513-b570-ed9745e7b66b\": {\"type\": \"entry\", \"label\": \"Button\", \"value\": \"{entry:4@1:url}\", \"target\": \"_blank\"}}',1,'2024-11-22 22:26:32','2024-11-22 22:26:32','cd3498c0-6ac9-4813-a621-eb5a4e4ef3c7'),(28,28,1,NULL,'__temp_irzzmbpgenckudqsskbpgzwwrzsjkdlxygrb',NULL,'{\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\": \"c-button-primary\", \"e4a35e4f-b60c-4513-b570-ed9745e7b66b\": {\"type\": \"entry\", \"label\": \"Another button\", \"value\": \"{entry:4@1:url}\", \"target\": null}}',1,'2024-11-22 22:39:03','2024-11-22 22:39:03','df619d4d-6358-464b-b520-ffb9eb2c59b7'),(29,29,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-11-22 22:39:03','2024-11-22 22:39:03','7b64f32b-5224-46d4-bfd8-4efc110dd1ae'),(30,30,1,NULL,'__temp_jqzhbvqvdnhhvabixqsoxumltfomqctslpgf',NULL,'{\"312c1fff-6c1f-46c5-a23a-4d649aa751e7\": \"<p>Test title</p>\", \"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\"}',1,'2024-11-22 22:39:03','2024-11-22 22:39:03','f58297fe-af78-4224-8fec-4d18c7db9028'),(31,31,1,NULL,'__temp_irzzmbpgenckudqsskbpgzwwrzsjkdlxygrb',NULL,'{\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\": \"c-button-primary\", \"e4a35e4f-b60c-4513-b570-ed9745e7b66b\": {\"type\": \"entry\", \"label\": \"Another button\", \"value\": \"{entry:4@1:url}\", \"target\": null}}',1,'2024-11-22 22:39:03','2024-11-22 22:39:03','22e68c60-4a4f-414c-9c54-94c0ed95fecd'),(33,33,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-11-22 22:47:39','2024-11-22 22:47:39','cde36341-2d1d-4d8c-979c-cd774127a231'),(36,36,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h4>Paragraphs</h4><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore! <a href=\\\"https://digitalastronaut.be/\\\">digital astronaut</a></p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h4>Unordered list</h4><ul><li>List item</li><li>List item</li><li>List item</li></ul><h4>Ordered list</h4><ol><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ol><h4>Block quote</h4><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h4>Tables</h4><figure class=\\\"table\\\"><table><thead><tr><th>Firstname</th><th>Lastname</th><th>Phone number</th><th>E-mailaddress</th><th>Country</th></tr></thead><tbody><tr><td>John</td><td>Doe</td><td>+32 123 45 67 89</td><td>johndoe@gmail.com</td><td>Belgium</td></tr><tr><td>Peter</td><td>Pingpong</td><td>+32 111 22 33 44</td><td>peterpingpong@hotmail.com</td><td>Frankrijk</td></tr></tbody></table></figure><p> </p>\"}',1,'2024-12-20 09:07:45','2025-03-14 11:31:53','27b1a704-7b38-48c0-a715-583deb0197ba'),(37,37,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 09:07:45','2024-12-20 09:07:45','d9ca52d3-52cc-44a9-8690-e2168e3b28bc'),(38,38,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h2>Paragraphs</h2>\"}',1,'2024-12-20 09:07:45','2024-12-20 09:07:45','89b13f83-4a79-440d-946a-bab79114cf16'),(41,41,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 09:18:23','2024-12-20 09:18:23','744c607a-0e2d-4a5d-8aed-f783abf2088b'),(42,42,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h2>Paragraphs</h2><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore!</p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, cum fuga voluptates quasi adipisci aspernatur odio delectus molestiae pariatur eaque eos. Hic velit quis similique dolorum voluptas unde id?</p>\"}',1,'2024-12-20 09:18:23','2024-12-20 09:18:23','88430a39-6a94-4ae4-a420-3db82628e00d'),(45,45,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 09:20:51','2024-12-20 09:20:51','3f86aec9-d5db-4547-a199-30bb75c65a44'),(46,46,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h3>This is a heading 2</h3><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore!</p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, cum fuga voluptates quasi adipisci aspernatur odio delectus molestiae pariatur eaque eos. Hic velit quis similique dolorum voluptas unde id?</p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ul><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ul><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote>\"}',1,'2024-12-20 09:20:51','2024-12-20 09:20:51','e4e2c566-4124-4780-99e9-4cf03abb2aca'),(49,49,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 09:21:51','2024-12-20 09:21:51','78a8c6ca-f732-438f-9be1-b6659734a1f2'),(50,50,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h3>This is a heading 2</h3><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore!</p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ul><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ul><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h3>Tables</h3>\"}',1,'2024-12-20 09:21:51','2024-12-20 09:21:51','1bbe31a3-06c7-4ec3-8721-9f104a2d5677'),(53,53,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 09:45:11','2024-12-20 09:45:11','621435bc-1f6d-48c5-9d6b-1f8e7ae1d8b5'),(54,54,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore!</p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ul><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ul><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h3>Tables</h3>\"}',1,'2024-12-20 09:45:11','2024-12-20 09:45:11','29e348a5-3cae-44f9-b7d9-7cf9939fe6ae'),(57,57,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 09:58:32','2024-12-20 09:58:32','595fdac9-50e7-4ec4-a44e-dd9deb6f2a88'),(58,58,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore!</p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ol><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ol><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h3>Tables</h3>\"}',1,'2024-12-20 09:58:32','2024-12-20 09:58:32','ab6aac5b-9a95-4992-be70-4c4eaf091f45'),(61,61,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 10:09:11','2024-12-20 10:09:11','72fcefc4-2491-4da0-b119-bc13c6ffe764'),(62,62,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore! <a href=\\\"https://digitalastronaut.be/\\\">digital astronaut</a></p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ol><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ol><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h3>Tables</h3><figure class=\\\"table\\\"><table><tbody><tr><td>Firstname</td><td>Lastname</td><td>Phone number</td><td>E-mailaddress</td><td>Country</td></tr><tr><td>John</td><td>Doe</td><td>+32 123 45 67 89</td><td>johndoe@gmail.com</td><td>Belgium</td></tr><tr><td>Peter</td><td>Pingpong</td><td>+32 111 22 33 44</td><td>peterpingpong@hotmail.com</td><td>Frankrijk</td></tr></tbody></table></figure><p> </p>\"}',1,'2024-12-20 10:09:11','2024-12-20 10:09:11','c4033a4b-4762-434c-94e9-55535cd8ec74'),(65,65,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 10:15:56','2024-12-20 10:15:56','2987e690-f138-4e66-8c72-08a7acd5bd62'),(66,66,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore! <a href=\\\"https://digitalastronaut.be/\\\">digital astronaut</a></p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ol><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ol><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h3>Tables</h3><figure class=\\\"table\\\"><table><thead><tr><th>Firstname</th><th>Lastname</th><th>Phone number</th><th>E-mailaddress</th><th>Country</th></tr></thead><tbody><tr><td>John</td><td>Doe</td><td>+32 123 45 67 89</td><td>johndoe@gmail.com</td><td>Belgium</td></tr><tr><td>Peter</td><td>Pingpong</td><td>+32 111 22 33 44</td><td>peterpingpong@hotmail.com</td><td>Frankrijk</td></tr></tbody></table></figure><p> </p>\"}',1,'2024-12-20 10:15:56','2024-12-20 10:15:56','28d535a2-1d14-4368-bc0f-aa15ac2f2e56'),(70,70,1,NULL,'__temp_rahjrfwznkwfhzqutlhjzoekocfeontlzfqc',NULL,'{\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\": \"c-button-primary\", \"17c79c1b-dba6-4c1e-8db3-6d3aaabfaa91\": {\"type\": \"entry\", \"label\": null, \"value\": \"{entry:4@1:url}\", \"target\": null}, \"5282cba7-8acf-46e1-b231-89a9ec58e01b\": \"_self\", \"c4f16b55-1f41-401a-b093-f360e013fbe0\": \"Test button\"}',1,'2024-12-20 15:41:13','2024-12-20 15:41:13','6571d1f8-8576-47d9-8f77-abd8b6ca9fae'),(71,71,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2024-12-20 15:41:13','2024-12-20 15:41:13','345c904f-7276-4859-b8d8-35d7fe605613'),(72,72,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h3>Paragraphs</h3><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore! <a href=\\\"https://digitalastronaut.be/\\\">digital astronaut</a></p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h3>Unordered list</h3><ul><li>List item</li><li>List item</li><li>List item</li></ul><h3>Ordered list</h3><ol><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ol><h3>Block quote</h3><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h3>Tables</h3><figure class=\\\"table\\\"><table><thead><tr><th>Firstname</th><th>Lastname</th><th>Phone number</th><th>E-mailaddress</th><th>Country</th></tr></thead><tbody><tr><td>John</td><td>Doe</td><td>+32 123 45 67 89</td><td>johndoe@gmail.com</td><td>Belgium</td></tr><tr><td>Peter</td><td>Pingpong</td><td>+32 111 22 33 44</td><td>peterpingpong@hotmail.com</td><td>Frankrijk</td></tr></tbody></table></figure><p> </p>\"}',1,'2024-12-20 15:41:13','2024-12-20 15:41:13','e2276a26-c5ab-4398-8601-fdd9f2584d5d'),(73,73,1,NULL,'__temp_rahjrfwznkwfhzqutlhjzoekocfeontlzfqc',NULL,'{\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\": \"c-button-primary\", \"17c79c1b-dba6-4c1e-8db3-6d3aaabfaa91\": {\"type\": \"entry\", \"label\": null, \"value\": \"{entry:4@1:url}\", \"target\": null}, \"5282cba7-8acf-46e1-b231-89a9ec58e01b\": \"_self\", \"c4f16b55-1f41-401a-b093-f360e013fbe0\": \"Test button\"}',1,'2024-12-20 15:41:13','2024-12-20 15:41:13','6e790930-5903-4621-8bd0-4d88a3c2298c'),(74,74,1,NULL,'__temp_bdmigfcmkwmzwqgwtbguvmdiwhcsrumbaucr',NULL,'{\"40ed50a6-3625-4738-bc83-38cfb5c7856c\": \"Home\", \"420f6282-22bb-49d5-ad53-634acb1e6386\": \"_self\", \"7b6b8d88-d146-4b44-87b7-d226061a4ba2\": {\"type\": \"entry\", \"label\": null, \"value\": \"{entry:4@1:url}\", \"target\": null}}',1,'2024-12-20 15:57:16','2024-12-20 15:57:28','22f4ac91-1231-482f-91e1-080cebb6d26e'),(75,75,1,NULL,'__temp_ufignruyyxvhoksfplqehalzjhkebytqqdne',NULL,'{\"4fb1eda8-5465-4a7b-98e6-5b49864eb261\": \"Sub link 1\", \"a3bd6039-d017-40d2-9bab-04c8f6ac8ae6\": {\"type\": \"entry\", \"label\": null, \"value\": \"{entry:4@1:url}\", \"target\": null}, \"c867ed4f-178c-4a4f-a835-f9ed45853d25\": \"_self\"}',1,'2024-12-20 15:57:31','2024-12-20 15:57:50','339d5bb7-e48e-42e5-86de-06d0176ecaef'),(76,76,1,NULL,'__temp_rgieumrwftbxkgnakrexgmlgucwcqeuuxspg',NULL,'{\"4fb1eda8-5465-4a7b-98e6-5b49864eb261\": \"Sub link 2\", \"a3bd6039-d017-40d2-9bab-04c8f6ac8ae6\": {\"type\": \"entry\", \"label\": null, \"value\": \"{entry:4@1:url}\", \"target\": null}, \"c867ed4f-178c-4a4f-a835-f9ed45853d25\": \"_self\"}',1,'2024-12-20 15:58:01','2024-12-20 15:58:10','91b8140f-9fd2-41dd-b560-86ad795f8d48'),(77,77,1,'Privacy policy','privacy-policy','privacy-policy','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Privacy policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}, \"facebook\": {\"title\": \"Privacy policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-01-03 12:56:46','2025-01-03 12:58:54','d4c22b07-97d2-46ab-a21b-55522629d4e0'),(78,78,1,'Privacy policy','privacy-policy','pages/privacy-policy','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Privacy policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}, \"facebook\": {\"title\": \"Privacy policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-01-03 12:56:56','2025-01-03 12:56:56','2aba303e-1cc2-45f5-a338-e36120cb3be9'),(79,79,1,'Terms of service','terms-of-service','terms-of-service','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Terms of - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}, \"facebook\": {\"title\": \"Terms of - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-01-03 13:00:12','2025-01-03 13:00:24','f48ed723-524d-431d-887d-e8a5fd9e04da'),(80,80,1,'Terms of service','terms-of-service','terms-of-service','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Terms of - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}, \"facebook\": {\"title\": \"Terms of - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-01-03 13:00:24','2025-01-03 13:00:24','78027dcd-800a-426f-ae2b-2c35e987e304'),(81,81,1,'Cookie policy','cookie-policy','cookie-policy','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Cookie policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}, \"facebook\": {\"title\": \"Cookie policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-01-03 13:00:27','2025-01-03 13:00:35','8748cd68-11ed-442a-83d8-2b3da18f0026'),(82,82,1,'Cookie policy','cookie-policy','cookie-policy','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"\", \"social\": {\"twitter\": {\"title\": \"Cookie policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}, \"facebook\": {\"title\": \"Cookie policy - craft-boilerplate\", \"handle\": null, \"imageId\": \"\", \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": \"\"}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-01-03 13:00:32','2025-01-03 13:00:32','b5877a77-6cb3-43b0-a4aa-b8214010b62c'),(85,85,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-03-14 11:31:53','2025-03-14 11:31:53','13beb052-1295-4ac0-9824-14c6476bc4ad'),(86,86,1,NULL,'__temp_ypjmaeikehqiycnefzlwhnifkkyctkgqjydl',NULL,'{\"c5081a8a-b23c-437a-adf6-b340842dbcb2\": \"<h2>This is a heading 2</h2><h3>This is a heading 3</h3><h4>This is a heading 4</h4><h5>This is a heading 5</h5><h6>This is a heading 6</h6><h4>Paragraphs</h4><p>Lorem ipsum dolor sit <strong>amet consectetur adipisicing elit. Nisi dolor dignissimos quaerat quod quasi sed minima</strong> praesentium beatae odit quidem esse fuga impedit quia, unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque. Accusantium hic laboriosam vero vel corrupti perspiciatis, aperiam perferendis dolores, ut cupiditate ipsa magni labore! <a href=\\\"https://digitalastronaut.be/\\\">digital astronaut</a></p><p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis, reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente? Pariatur ea similique nam ipsam itaque quos? <u>Porro minus sequi tenetur officiis optio.</u> Expedita voluptate est earum ex tenetur id, nobis architecto ipsam, <i>cum fuga voluptates quasi adipisci</i> aspernatur odio delectus molestiae pariatur eaque eos. <s>Hic velit quis similique dolorum voluptas unde id?</s></p><h4>Unordered list</h4><ul><li>List item</li><li>List item</li><li>List item</li></ul><h4>Ordered list</h4><ol><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li><li>Ordered list item</li></ol><h4>Block quote</h4><blockquote><p>Pariatur ea similique nam ipsam itaque quos? Porro minus sequi tenetur officiis optio. Hic velit quis similique dolorum voluptas unde id?</p></blockquote><h4>Tables</h4><figure class=\\\"table\\\"><table><thead><tr><th>Firstname</th><th>Lastname</th><th>Phone number</th><th>E-mailaddress</th><th>Country</th></tr></thead><tbody><tr><td>John</td><td>Doe</td><td>+32 123 45 67 89</td><td>johndoe@gmail.com</td><td>Belgium</td></tr><tr><td>Peter</td><td>Pingpong</td><td>+32 111 22 33 44</td><td>peterpingpong@hotmail.com</td><td>Frankrijk</td></tr></tbody></table></figure><p> </p>\"}',1,'2025-03-14 11:31:53','2025-03-14 11:31:53','ecf8ab8f-44a7-4063-b22e-458e4fdec0fb'),(87,87,1,'Person',NULL,NULL,NULL,1,'2025-03-14 11:37:21','2025-03-14 11:37:21','28358e92-355e-4890-88d9-811741286cba'),(89,89,1,'Home','homeextra','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-03-14 11:39:35','2025-03-14 11:39:35','3cc8b0b5-a384-40da-989f-2904154d48ec'),(91,91,1,'Home','home-extra','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-03-14 11:39:53','2025-03-14 11:39:53','d188bb93-34cc-4111-86b2-01a51e1d16ec'),(92,92,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": null, \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-03-14 11:40:04','2025-03-14 11:40:04','f0a456a5-28b1-4ca8-b9b3-54895ec0fa0e'),(95,95,1,NULL,'__temp_ztopivzawpazdxmkwevmkpazsxjzrlfoywsz',NULL,'{\"a4c0a2a1-4545-44dc-b3c3-a1ddb151aade\": \"small\"}',1,'2025-05-26 08:39:52','2025-05-26 08:43:46','95387811-41ad-408f-a925-9b5f751115c4'),(96,96,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-05-26 08:39:52','2025-05-26 08:39:52','261d6ad1-4432-4c9b-8e82-e2e4ca380aab'),(97,97,1,NULL,'__temp_ztopivzawpazdxmkwevmkpazsxjzrlfoywsz',NULL,'{\"a4c0a2a1-4545-44dc-b3c3-a1ddb151aade\": \"medium\"}',1,'2025-05-26 08:39:52','2025-05-26 08:39:52','2595c739-455f-48e2-be70-f18ca32b0c4c'),(98,98,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-05-26 08:41:47','2025-05-26 08:41:47','37bde5d5-81be-49ab-a600-479cf4bb5415'),(99,99,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-05-26 08:42:07','2025-05-26 08:42:07','09c76a7a-96fc-4e15-a922-295c7e1e26d6'),(102,102,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-05-26 08:43:46','2025-05-26 08:43:46','798927ff-c9ed-43f4-9f97-cce88de7c726'),(103,103,1,NULL,'__temp_ztopivzawpazdxmkwevmkpazsxjzrlfoywsz',NULL,'{\"a4c0a2a1-4545-44dc-b3c3-a1ddb151aade\": \"small\"}',1,'2025-05-26 08:43:46','2025-05-26 08:43:46','2c208d67-3dea-4168-96be-86b6dad4ffdf'),(104,104,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-05-26 08:46:42','2025-05-26 08:46:42','9396ffc4-65a5-456f-ace0-e5b346d4c2e0'),(105,105,1,'Home','home','__home__','{\"29fcd495-2a8f-498b-992c-d481dd7f72f5\": {\"score\": \"neutral\", \"social\": {\"twitter\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}, \"facebook\": {\"title\": [], \"handle\": \"\", \"imageId\": null, \"description\": []}}, \"advanced\": {\"robots\": [], \"canonical\": null}, \"keywords\": [], \"titleRaw\": [], \"descriptionRaw\": \"\"}}',1,'2025-06-17 08:07:17','2025-06-17 08:07:17','2977005e-2605-44b0-90b2-60624c204690');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (4,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-10-11 15:04:45','2024-10-11 15:04:45'),(5,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-10-11 15:04:45','2024-10-11 15:04:45'),(6,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-10-11 15:05:55','2024-10-11 15:05:55'),(7,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-10-29 15:31:53','2024-10-29 15:31:53'),(8,NULL,NULL,2,8,2,NULL,NULL,'pending',1,NULL,'2024-11-13 14:20:14','2025-04-23 11:14:05'),(9,NULL,NULL,2,15,5,NULL,NULL,'pending',1,NULL,'2024-11-13 14:25:58','2025-04-23 11:14:05'),(10,NULL,NULL,2,15,5,NULL,NULL,'pending',1,NULL,'2024-11-13 14:28:56','2025-04-23 11:14:05'),(15,NULL,NULL,4,12,7,'2024-11-22 22:01:00',NULL,'live',0,0,'2024-11-22 22:02:43','2024-11-22 22:02:43'),(16,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-11-22 22:02:43','2024-11-22 22:02:43'),(17,NULL,NULL,16,12,7,'2024-11-22 22:01:00',NULL,'live',NULL,NULL,'2024-11-22 22:02:43','2024-11-22 22:02:43'),(21,NULL,NULL,15,18,6,'2024-11-22 22:26:00',NULL,'live',0,0,'2024-11-22 22:26:32','2024-11-22 22:26:32'),(22,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-11-22 22:26:32','2024-11-22 22:26:32'),(23,NULL,NULL,22,12,7,'2024-11-22 22:01:00',NULL,'live',NULL,NULL,'2024-11-22 22:26:32','2024-11-22 22:26:32'),(24,NULL,NULL,23,18,6,'2024-11-22 22:26:00',NULL,'live',NULL,NULL,'2024-11-22 22:26:32','2024-11-22 22:26:32'),(28,NULL,NULL,15,18,6,'2024-11-22 22:38:00',NULL,'live',0,0,'2024-11-22 22:39:03','2024-11-22 22:39:03'),(29,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-11-22 22:39:03','2024-11-22 22:39:03'),(30,NULL,NULL,29,12,7,'2024-11-22 22:01:00',NULL,'live',NULL,NULL,'2024-11-22 22:39:03','2024-11-22 22:39:03'),(31,NULL,NULL,30,18,6,'2024-11-22 22:38:00',NULL,'live',NULL,NULL,'2024-11-22 22:39:03','2024-11-22 22:39:03'),(33,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-11-22 22:47:39','2024-11-22 22:47:39'),(36,NULL,NULL,4,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:07:45','2024-12-20 09:07:45'),(37,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 09:07:45','2024-12-20 09:07:45'),(38,NULL,NULL,37,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:07:45','2024-12-20 09:07:45'),(41,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 09:18:23','2024-12-20 09:18:23'),(42,NULL,NULL,41,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:18:23','2024-12-20 09:18:23'),(45,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 09:20:51','2024-12-20 09:20:51'),(46,NULL,NULL,45,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:20:51','2024-12-20 09:20:51'),(49,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 09:21:51','2024-12-20 09:21:51'),(50,NULL,NULL,49,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:21:51','2024-12-20 09:21:51'),(53,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 09:45:11','2024-12-20 09:45:11'),(54,NULL,NULL,53,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:45:11','2024-12-20 09:45:11'),(57,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 09:58:32','2024-12-20 09:58:32'),(58,NULL,NULL,57,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 09:58:32','2024-12-20 09:58:32'),(61,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 10:09:11','2024-12-20 10:09:11'),(62,NULL,NULL,61,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 10:09:11','2024-12-20 10:09:11'),(65,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 10:15:56','2024-12-20 10:15:56'),(66,NULL,NULL,65,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 10:15:56','2024-12-20 10:15:56'),(70,NULL,NULL,36,18,6,'2024-12-20 15:40:00',NULL,'live',NULL,NULL,'2024-12-20 15:41:13','2024-12-20 15:41:13'),(71,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2024-12-20 15:41:13','2024-12-20 15:41:13'),(72,NULL,NULL,71,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2024-12-20 15:41:13','2024-12-20 15:41:13'),(73,NULL,NULL,72,18,6,'2024-12-20 15:40:00',NULL,'live',NULL,NULL,'2024-12-20 15:41:13','2024-12-20 15:41:13'),(74,NULL,NULL,2,26,10,'2024-12-20 15:58:00',NULL,'live',0,0,'2024-12-20 15:57:16','2024-12-20 15:58:13'),(75,NULL,NULL,74,19,8,'2024-12-20 15:57:00',NULL,'live',0,0,'2024-12-20 15:57:31','2024-12-20 15:57:52'),(76,NULL,NULL,74,19,8,'2024-12-20 15:58:00',NULL,'live',0,0,'2024-12-20 15:58:01','2024-12-20 15:58:11'),(77,2,NULL,NULL,NULL,3,'2025-01-03 12:56:00',NULL,'live',NULL,NULL,'2025-01-03 12:56:46','2025-01-03 12:56:56'),(78,2,NULL,NULL,NULL,3,'2025-01-03 12:56:00',NULL,'live',NULL,NULL,'2025-01-03 12:56:56','2025-01-03 12:56:56'),(79,2,NULL,NULL,NULL,3,'2025-01-03 13:00:00',NULL,'live',NULL,NULL,'2025-01-03 13:00:12','2025-01-03 13:00:24'),(80,2,NULL,NULL,NULL,3,'2025-01-03 13:00:00',NULL,'live',NULL,NULL,'2025-01-03 13:00:24','2025-01-03 13:00:24'),(81,2,NULL,NULL,NULL,3,'2025-01-03 13:00:00',NULL,'live',NULL,NULL,'2025-01-03 13:00:27','2025-01-03 13:00:32'),(82,2,NULL,NULL,NULL,3,'2025-01-03 13:00:00',NULL,'live',NULL,NULL,'2025-01-03 13:00:32','2025-01-03 13:00:32'),(85,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-03-14 11:31:53','2025-03-14 11:31:53'),(86,NULL,NULL,85,12,7,'2024-12-20 09:05:00',NULL,'live',NULL,NULL,'2025-03-14 11:31:53','2025-03-14 11:31:53'),(89,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-03-14 11:39:35','2025-03-14 11:39:35'),(91,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-03-14 11:39:53','2025-03-14 11:39:53'),(92,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-03-14 11:40:04','2025-03-14 11:40:04'),(95,NULL,NULL,4,12,9,'2025-05-26 08:39:00',NULL,'live',NULL,NULL,'2025-05-26 08:39:52','2025-05-26 08:39:52'),(96,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-05-26 08:39:52','2025-05-26 08:39:52'),(97,NULL,NULL,96,12,9,'2025-05-26 08:39:00',NULL,'live',NULL,NULL,'2025-05-26 08:39:52','2025-05-26 08:39:52'),(98,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-05-26 08:41:47','2025-05-26 08:41:47'),(99,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-05-26 08:42:07','2025-05-26 08:42:07'),(102,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-05-26 08:43:46','2025-05-26 08:43:46'),(103,NULL,NULL,102,12,9,'2025-05-26 08:39:00',NULL,'live',NULL,NULL,'2025-05-26 08:43:46','2025-05-26 08:43:46'),(104,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-05-26 08:46:42','2025-05-26 08:46:42'),(105,1,NULL,NULL,NULL,3,'2024-10-11 15:04:00',NULL,'live',NULL,NULL,'2025-06-17 08:07:17','2025-06-17 08:07:17');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries_authors` VALUES (77,1,1),(78,1,1),(79,1,1),(80,1,1),(81,1,1),(82,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,2,'Button','button','square','teal',0,'site',NULL,'',0,'site',NULL,0,'2024-10-11 14:26:06','2024-10-11 14:53:57','2024-11-22 21:36:06','f188d2f4-40cb-4add-83ed-96a5f83a59e9'),(2,3,'Link','link','link','teal',0,'site',NULL,'',0,'site',NULL,0,'2024-10-11 14:33:43','2024-11-13 14:22:21','2024-11-22 21:35:57','2b107021-5655-49ea-8ca0-5ef5fc2d9f62'),(3,6,'Page','page','file','violet',1,'site',NULL,'',1,'site',NULL,1,'2024-10-11 14:51:21','2024-10-11 14:51:21',NULL,'d7e8d0bc-8052-499d-99b8-d622687dfee7'),(4,7,'Split','split','table-columns','sky',0,'site',NULL,'',0,'site',NULL,1,'2024-10-11 14:53:38','2024-10-11 14:53:38','2024-11-22 21:36:10','458b8d9b-de18-4454-afbb-fdd9d0bfeb84'),(5,8,'Navigation Link','navigationLink','link','teal',0,'site',NULL,'',0,'site',NULL,0,'2024-11-13 14:21:56','2024-11-13 14:22:25','2024-11-22 21:36:00','5c7ddd03-e7f1-49c4-8c80-8d542a79d8f2'),(6,9,'Button','button','square','teal',0,'site',NULL,'',0,'site',NULL,1,'2024-11-22 21:49:51','2024-11-22 21:49:51',NULL,'aa95f819-8179-4afd-8972-f3d4b77f3056'),(7,10,'Text','text','text','sky',0,'site',NULL,'',0,'site',NULL,1,'2024-11-22 21:51:09','2024-11-22 21:51:09',NULL,'704846e3-cfa0-4a1f-8f8f-f65b73c9de47'),(8,11,'Link','link','link','teal',0,'site',NULL,'',0,'site',NULL,1,'2024-11-22 21:54:57','2024-11-22 22:56:50',NULL,'28efc0ec-8432-4ee6-b8ad-5b109779166c'),(9,12,'Spacing','spacing','up-right-and-down-left-from-center','sky',0,'site',NULL,'',0,'site',NULL,1,'2024-12-20 09:10:36','2024-12-20 09:10:36',NULL,'ca6f639a-12fb-4ecd-8e43-1c9b5e863711'),(10,13,'Link menu','linkMenu','link','teal',0,'site',NULL,NULL,0,'site',NULL,1,'2024-12-20 15:52:24','2025-05-26 09:23:24',NULL,'72688bf2-9dcf-4032-9899-7d39ab1986f0');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"abe32ab9-b13c-4572-8cbf-5d6cdaed2454\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"f568f977-c63e-4a3b-acab-b42e920cd68d\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-11T14:18:52+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"43435a90-40d6-48d8-aef7-d547ca4f7ecf\", \"cols\": null, \"name\": null, \"rows\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"alt\", \"dateAdded\": \"2024-10-11T14:22:07+00:00\", \"requirable\": true, \"orientation\": null, \"placeholder\": null, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-11 14:22:07','2024-10-11 14:22:07',NULL,'18d8e1db-5acd-48b5-b997-d2cbbe681f03'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"15efb651-ca13-49c3-b6eb-0b05f12df216\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"26f98a21-0ce3-4d17-83ea-ac74af7f5bd6\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-11T14:24:11+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"af6bc050-c401-4e35-9496-660eac34a28f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5daf3ecb-2eef-4d14-b841-c8eaef369ee7\", \"required\": false, \"dateAdded\": \"2024-10-11T14:43:39+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"7cdc7a6b-b8bf-4373-95b8-eac221a0daab\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"labelField\", \"warning\": null, \"fieldUid\": \"4381ddb2-8940-4d25-8e42-5a770b533b71\", \"required\": false, \"dateAdded\": \"2024-10-11T14:26:06+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ab92f1dc-29d0-4819-8c4a-5ff570259b02\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7947a42a-167a-4d11-a4c2-dcf9fa46eb65\", \"required\": false, \"dateAdded\": \"2024-10-11T14:43:39+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-11 14:26:06','2024-11-13 14:23:10','2024-11-22 21:36:06','613e4480-adf7-4784-8e56-80abd96de47d'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bdbb13cd-4bd2-41f3-82ce-3976d5c533ca\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"25963d7a-eaf5-4f91-8d66-4bf5c3b263bd\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-11T14:31:05+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"721c9437-6cde-4d5e-9bd4-e07e9d3e044f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"labelField\", \"warning\": null, \"fieldUid\": \"4381ddb2-8940-4d25-8e42-5a770b533b71\", \"required\": false, \"dateAdded\": \"2024-10-11T14:33:43+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"64c71d1b-75af-4382-9d98-b6a229624709\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5daf3ecb-2eef-4d14-b841-c8eaef369ee7\", \"required\": false, \"dateAdded\": \"2024-10-11T14:33:43+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"2d8e0d7a-a578-44e5-8821-76b2df26e06f\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"a26632d1-c5f6-43fc-955c-bcd3b0d3226b\", \"required\": false, \"dateAdded\": \"2024-10-11T14:43:50+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-11 14:33:43','2024-11-13 14:22:49','2024-11-22 21:35:57','22a52177-f7e1-481b-b05f-33d76b1d7072'),(4,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"a8ca7c72-d6ae-4d36-8f15-8514326596e0\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"5940cf61-a6d8-4d9a-ad83-5a1764498066\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"841b576a-8964-4701-ac7a-8789c2ee20d1\", \"required\": false, \"dateAdded\": \"2024-12-20T15:53:26+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-10-11 14:44:15','2024-12-20 15:53:27',NULL,'bb5c7841-023c-4e25-aff2-a3bec954e85a'),(5,'craft\\elements\\GlobalSet','{\"tabs\": [{\"uid\": \"3a08dc35-eb7f-4b71-8bc7-14416fe5cbd2\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"ae41e94b-adee-43e0-a814-1430576a90f9\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"883ee07a-821a-4772-acaf-e9a78ff34015\", \"required\": false, \"dateAdded\": \"2024-12-20T15:54:36+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-10-11 14:44:41','2024-12-20 15:54:36',NULL,'4ad04a6b-7b44-407d-ab92-92a537da1d67'),(6,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"0e27f7e0-2bd5-4aa3-b416-8d1f60607845\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"8e99c3f8-8947-45b5-bd0c-b31135dbe136\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-11T14:49:52+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"7f96e298-8f7d-4fe5-a49d-5cc2f976c676\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"23bc0810-e9d7-499e-8398-83de3788b62c\", \"required\": false, \"dateAdded\": \"2024-10-11T15:06:26+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"0c63d3c5-ccc3-482b-926e-3bc3cefec74c\", \"name\": \"SEO\", \"elements\": [{\"tip\": null, \"uid\": \"29fcd495-2a8f-498b-992c-d481dd7f72f5\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"4b9c49b3-1c60-4cf8-90ea-24baf113c4ee\", \"required\": false, \"dateAdded\": \"2024-11-13T14:19:35+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-11 14:51:21','2024-11-13 14:19:35',NULL,'ccf03281-b22e-457e-8e71-37332ee99ce8'),(7,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"cb23655e-264b-442d-b3f4-1fd9de0a47d5\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"fb3d716c-680f-48e8-8779-738216b73171\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-10-11T14:51:22+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"cb99fa8c-7d3f-4b0d-89ed-834578777bee\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9a80c602-8f9a-47fa-9f77-bec83a7c2418\", \"required\": false, \"dateAdded\": \"2024-10-11T14:53:38+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"9db976d2-2170-4ee5-b3bf-a5e1c646d3bb\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"e7f650f0-adf2-4ec9-95af-8db8542b1931\", \"required\": false, \"dateAdded\": \"2024-10-11T14:55:14+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"ed7aa9e5-7fc9-4d01-bf40-db8bae1f887b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d1ab0c28-7124-4171-99dd-27b8f9805017\", \"required\": false, \"dateAdded\": \"2024-10-11T14:53:38+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"1a6571f9-2cfa-442f-b435-c70bd4ac2880\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"18343ac5-aac0-4eaf-9e48-a56879dc06dc\", \"required\": false, \"dateAdded\": \"2024-10-11T14:53:38+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}, {\"uid\": \"ed931883-3b17-4ce4-96eb-a7a6b345bc0a\", \"name\": \"Layout\", \"elements\": [], \"userCondition\": null, \"elementCondition\": null}]}','2024-10-11 14:53:38','2024-11-13 14:19:03','2024-11-22 21:36:10','e78d7194-f191-4d1c-9c58-381dc5b4ff53'),(8,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"bc05dfcf-d398-4f58-8f0f-4f9a092a136b\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"a07ea039-72e8-49bc-94f0-07f514a86cde\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"dateAdded\": \"2024-11-13T14:19:43+00:00\", \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"05655a30-8631-47fc-998a-79f91af73e72\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"labelField\", \"warning\": null, \"fieldUid\": \"4381ddb2-8940-4d25-8e42-5a770b533b71\", \"required\": false, \"dateAdded\": \"2024-11-13T14:21:56+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"4c34bfef-2297-47e0-8f5b-97d70b2f76dc\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"5daf3ecb-2eef-4d14-b841-c8eaef369ee7\", \"required\": false, \"dateAdded\": \"2024-11-13T14:21:56+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"0947452c-5432-45b5-9455-bd1e115ba2b0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Sub navigation\", \"width\": 100, \"handle\": \"subNavigatieField\", \"warning\": null, \"fieldUid\": \"fb3f5a71-9491-49f3-a6b2-3466268b73d9\", \"required\": false, \"dateAdded\": \"2024-11-13T14:21:56+00:00\", \"instructions\": \"Links die hier worden toegevoegd zullen verschijnen in een dropdown\", \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-11-13 14:21:56','2024-11-13 14:36:49','2024-11-22 21:36:00','c4e15855-980a-4b6a-b479-05e0b8462e62'),(9,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"f9e1cc15-c079-4dcd-95e2-2d2d9a1aa357\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"17c79c1b-dba6-4c1e-8db3-6d3aaabfaa91\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"a3045613-418c-483e-a666-fb4269b18c80\", \"required\": false, \"dateAdded\": \"2024-12-20T15:38:33+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": true, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"c4f16b55-1f41-401a-b093-f360e013fbe0\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"labelField\", \"warning\": null, \"fieldUid\": \"4381ddb2-8940-4d25-8e42-5a770b533b71\", \"required\": false, \"dateAdded\": \"2024-12-20T15:38:33+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": true, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"5282cba7-8acf-46e1-b231-89a9ec58e01b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9711e272-d70a-4399-adde-7368c097f72c\", \"required\": false, \"dateAdded\": \"2024-12-20T15:38:33+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"7947a42a-167a-4d11-a4c2-dcf9fa46eb65\", \"required\": false, \"dateAdded\": \"2024-11-22T21:49:51+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [\"layoutElement:c4f16b55-1f41-401a-b093-f360e013fbe0\", \"layoutElement:17c79c1b-dba6-4c1e-8db3-6d3aaabfaa91\"]}','2024-11-22 21:49:51','2024-12-20 15:58:53',NULL,'5729310c-3ea6-42f8-8947-2566188bb614'),(10,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"a9f5033b-447d-4c23-97f7-156ad2bf1fda\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"c5081a8a-b23c-437a-adf6-b340842dbcb2\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"d1ab0c28-7124-4171-99dd-27b8f9805017\", \"required\": false, \"dateAdded\": \"2024-11-22T22:00:54+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-11-22 21:51:09','2024-12-20 16:12:07',NULL,'5544227c-de0f-4abd-9b19-625fed60111d'),(11,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"eeab1e9b-c818-450f-b80a-ca21270a363a\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"a3bd6039-d017-40d2-9bab-04c8f6ac8ae6\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"a3045613-418c-483e-a666-fb4269b18c80\", \"required\": false, \"dateAdded\": \"2024-12-20T15:39:14+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": true, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"4fb1eda8-5465-4a7b-98e6-5b49864eb261\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"labelField\", \"warning\": null, \"fieldUid\": \"4381ddb2-8940-4d25-8e42-5a770b533b71\", \"required\": false, \"dateAdded\": \"2024-12-20T15:39:14+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": true, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"c867ed4f-178c-4a4f-a835-f9ed45853d25\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9711e272-d70a-4399-adde-7368c097f72c\", \"required\": false, \"dateAdded\": \"2024-12-20T15:39:14+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [\"layoutElement:4fb1eda8-5465-4a7b-98e6-5b49864eb261\", \"layoutElement:a3bd6039-d017-40d2-9bab-04c8f6ac8ae6\"]}','2024-11-22 21:54:57','2024-12-20 15:58:59',NULL,'dc21ca45-42ec-4391-89d5-94412375ad8e'),(12,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"12ce648f-f124-4712-a239-fea8b1b4fc0a\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"a4c0a2a1-4545-44dc-b3c3-a1ddb151aade\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"48a3d45e-b4f5-49f2-a960-94adcb851007\", \"required\": false, \"dateAdded\": \"2024-12-20T09:10:36+00:00\", \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": []}','2024-12-20 09:10:36','2024-12-20 09:10:36',NULL,'c53f3b56-8817-468f-bd56-2bff7a3319bd'),(13,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"8a293e0e-f3b3-42fe-a621-30fb3ffc255e\", \"name\": \"Content\", \"elements\": [{\"tip\": null, \"uid\": \"7b6b8d88-d146-4b44-87b7-d226061a4ba2\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"a3045613-418c-483e-a666-fb4269b18c80\", \"required\": false, \"dateAdded\": \"2024-12-20T15:52:24+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": true, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"40ed50a6-3625-4738-bc83-38cfb5c7856c\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Label\", \"width\": 100, \"handle\": \"labelField\", \"warning\": null, \"fieldUid\": \"4381ddb2-8940-4d25-8e42-5a770b533b71\", \"required\": false, \"dateAdded\": \"2024-12-20T15:52:24+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": true, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"420f6282-22bb-49d5-ad53-634acb1e6386\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9711e272-d70a-4399-adde-7368c097f72c\", \"required\": false, \"dateAdded\": \"2024-12-20T15:52:24+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"18d1e987-82c9-4983-94e9-d529a8d6525a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Sub Links\", \"width\": 100, \"handle\": \"subLinksField\", \"warning\": null, \"fieldUid\": \"2ab57b6f-1852-449c-9afa-30c833317b58\", \"required\": false, \"dateAdded\": \"2024-12-20T15:52:24+00:00\", \"instructions\": null, \"editCondition\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}], \"cardView\": [\"layoutElement:40ed50a6-3625-4738-bc83-38cfb5c7856c\", \"layoutElement:7b6b8d88-d146-4b44-87b7-d226061a4ba2\"]}','2024-12-20 15:52:24','2025-05-26 09:23:24',NULL,'3053f7ed-f04f-4f24-bd03-7a1dccd1388c');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,'SEO','seo','global',NULL,NULL,1,'none',NULL,'ether\\seo\\fields\\SeoField','{\"description\":\"\",\"hideSocial\":\"\",\"robots\":[\"\",\"\",\"\",\"\",\"\",\"\"],\"socialImage\":\"\",\"suffixAsPrefix\":null,\"title\":[{\"key\":\"1\",\"locked\":\"0\",\"template\":\"{title}\"},{\"key\":\"2\",\"locked\":\"1\",\"template\":\" - {{ siteName }}\"}],\"titleSuffix\":null}','2024-10-11 14:00:36','2024-12-20 15:43:21',NULL,'4b9c49b3-1c60-4cf8-90ea-24baf113c4ee'),(2,'Text','textField','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-10-11 14:01:37','2024-11-22 21:52:48',NULL,'4381ddb2-8940-4d25-8e42-5a770b533b71'),(3,'Rich Text','richTextField','global',NULL,NULL,1,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"characterLimit\":null,\"ckeConfig\":\"857c718e-b5a7-402c-8bcd-e92b86306176\",\"createButtonLabel\":null,\"defaultTransform\":null,\"expandEntryButtons\":false,\"fullGraphqlData\":false,\"parseEmbeds\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":true,\"sourceEditingGroups\":[\"__ADMINS__\"],\"wordLimit\":null}','2024-10-11 14:09:19','2025-06-17 08:05:50',NULL,'d1ab0c28-7124-4171-99dd-27b8f9805017'),(4,'Image','imageField','global',NULL,NULL,1,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultPlacement\":\"end\",\"defaultUploadLocationSource\":\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Add image\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-10-11 14:12:27','2025-06-17 08:04:22',NULL,'9a80c602-8f9a-47fa-9f77-bec83a7c2418'),(5,'URL','URLField','global',NULL,NULL,1,'none',NULL,'craft\\fields\\Link','{\"maxLength\":255,\"typeSettings\":{\"url\":{\"allowRootRelativeUrls\":\"\",\"allowAnchors\":\"\"},\"asset\":{\"sources\":[\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"],\"allowedKinds\":[\"image\"],\"showUnpermittedVolumes\":\"\",\"showUnpermittedFiles\":\"\"},\"entry\":{\"sources\":\"*\"}},\"types\":[\"url\",\"asset\",\"email\",\"entry\"]}','2024-10-11 14:31:58','2024-11-13 14:17:43','2024-11-22 21:36:46','5daf3ecb-2eef-4d14-b841-c8eaef369ee7'),(6,'Target','targetConfig','global',NULL,'Kies of de link moet openen in een nieuw tablad',0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"This window\",\"value\":\"_self\",\"default\":\"1\"},{\"label\":\"New window\",\"value\":\"_blank\",\"default\":\"\"}]}','2024-10-11 14:41:19','2024-11-13 14:18:15','2024-11-22 21:36:43','a26632d1-c5f6-43fc-955c-bcd3b0d3226b'),(7,'Button variant','buttonVariantConfig','global',NULL,NULL,0,'none',NULL,'craft\\fields\\ButtonGroup','{\"customOptions\":false,\"iconsOnly\":false,\"options\":[{\"label\":\"Primary\",\"value\":\"primary\",\"icon\":\"\",\"default\":\"1\"},{\"label\":\"Secondary\",\"value\":\"secondary\",\"icon\":\"\",\"default\":\"\"}]}','2024-10-11 14:41:59','2025-05-26 09:23:32',NULL,'7947a42a-167a-4d11-a4c2-dcf9fa46eb65'),(8,'Links','linksField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New Link\",\"entryTypes\":[\"2b107021-5655-49ea-8ca0-5ef5fc2d9f62\"],\"includeTableView\":false,\"maxEntries\":1,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2024-10-11 14:45:59','2024-10-11 14:45:59','2024-11-22 21:36:35','fb3f5a71-9491-49f3-a6b2-3466268b73d9'),(9,'Buttons','buttonsField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New Button\",\"entryTypes\":[\"f188d2f4-40cb-4add-83ed-96a5f83a59e9\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2024-10-11 14:47:26','2024-10-29 15:54:10','2024-11-22 21:37:12','18343ac5-aac0-4eaf-9e48-a56879dc06dc'),(10,'Link','linkField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New Link\",\"entryTypes\":[\"2b107021-5655-49ea-8ca0-5ef5fc2d9f62\"],\"includeTableView\":false,\"maxEntries\":1,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2024-10-11 14:49:19','2024-10-11 14:49:19','2024-11-22 21:36:32','4c934d3d-4c5a-4771-bd77-7c92de44f32a'),(11,'Button','buttonField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New Button\",\"entryTypes\":[\"f188d2f4-40cb-4add-83ed-96a5f83a59e9\"],\"includeTableView\":false,\"maxEntries\":1,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2024-10-11 14:49:54','2024-10-11 14:49:54','2024-11-22 21:37:03','fe3c8251-4266-4361-a5f6-63bbc681c5ef'),(12,'Blocks','blocksField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New Block\",\"defaultIndexViewMode\":\"cards\",\"entryTypes\":[\"704846e3-cfa0-4a1f-8f8f-f65b73c9de47\",\"ca6f639a-12fb-4ecd-8e43-1c9b5e863711\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"blocks\"}','2024-10-11 14:52:18','2024-12-20 09:10:56',NULL,'23bc0810-e9d7-499e-8398-83de3788b62c'),(13,'Title','titleField','global',NULL,NULL,1,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"*\",\"ckeConfig\":\"8eceae5c-bf72-475b-a84f-33735f3d3f1d\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":true,\"wordLimit\":null}','2024-10-11 14:54:25','2024-10-11 14:54:25',NULL,'e7f650f0-adf2-4ec9-95af-8db8542b1931'),(14,'Image Position','imagePositionConfig','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":\"No\",\"onLabel\":\"Yes\"}','2024-10-11 14:56:04','2024-10-11 14:59:18','2024-11-13 14:19:13','ff44c8a6-0d2e-42e4-8815-c7e8c2c0698d'),(15,'Navigation Links','navigationLinks','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New navigation link\",\"entryTypes\":[\"5c7ddd03-e7f1-49c4-8c80-8d542a79d8f2\"],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":false,\"viewMode\":\"cards\"}','2024-11-13 14:25:19','2024-11-13 14:25:38','2024-11-22 21:36:39','e754f081-ef63-4957-b25e-e036994e34ba'),(16,'Buttons Layout','buttonsLayoutConfig','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Row\",\"value\":\"\",\"default\":\"1\"},{\"label\":\"Column\",\"value\":\"c-buttons-column\",\"default\":\"\"}]}','2024-11-13 15:02:05','2024-11-13 15:02:05','2024-11-22 21:37:16','3e1129e3-eee8-4f8b-8b9e-be02dd73376b'),(17,'Link','linkField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New link\",\"defaultIndexViewMode\":\"cards\",\"entryTypes\":[\"28efc0ec-8432-4ee6-b8ad-5b109779166c\"],\"includeTableView\":false,\"maxEntries\":1,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":true,\"viewMode\":\"cards\"}','2024-11-22 21:41:57','2024-12-20 15:42:05',NULL,'05248eae-0d0d-4c9b-9c0f-da2e1ec1213a'),(18,'Buttons','buttonsField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"minEntries\":null,\"maxEntries\":null,\"viewMode\":\"cards\",\"showCardsInGrid\":true,\"includeTableView\":false,\"defaultTableColumns\":[],\"defaultIndexViewMode\":\"cards\",\"pageSize\":50,\"createButtonLabel\":\"New button\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null,\"siteSettings\":{\"e1acd264-0533-4dd7-8cfa-183423e1c25e\":[]},\"entryTypes\":[\"aa95f819-8179-4afd-8972-f3d4b77f3056\"]}','2024-11-22 21:53:43','2024-12-20 15:42:23',NULL,'4873bc46-6c2c-4e5a-8e84-cb8e312f20ad'),(19,'Links','linksField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New link\",\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"28efc0ec-8432-4ee6-b8ad-5b109779166c\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":true,\"viewMode\":\"cards\"}','2024-11-22 21:55:32','2025-05-26 09:23:45',NULL,'2ab57b6f-1852-449c-9afa-30c833317b58'),(20,'Images','imagesField','global',NULL,NULL,1,'none',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\",\"defaultUploadLocationSubpath\":null,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Add image\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2024-11-22 21:56:32','2024-11-22 21:58:49',NULL,'39dae8e0-9ae7-4d95-9088-aa5a0af11cbe'),(21,'Icon','iconField','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"None\",\"value\":\"\",\"default\":\"1\"}],\"customOptions\":false}','2024-11-22 21:59:40','2025-01-03 13:27:07',NULL,'2b9c20b9-9252-416a-b5a0-041473c84c8a'),(22,'URL','urlField','global',NULL,NULL,1,'none',NULL,'craft\\fields\\Link','{\"maxLength\":255,\"showLabelField\":false,\"showTargetField\":false,\"typeSettings\":{\"entry\":{\"sources\":\"*\"},\"url\":{\"allowRootRelativeUrls\":\"\",\"allowAnchors\":\"\"},\"asset\":{\"sources\":\"*\",\"allowedKinds\":[\"image\",\"pdf\"],\"showUnpermittedVolumes\":\"\",\"showUnpermittedFiles\":\"\"}},\"types\":[\"entry\",\"url\",\"asset\",\"email\"]}','2024-12-20 08:59:19','2024-12-20 08:59:19',NULL,'a3045613-418c-483e-a666-fb4269b18c80'),(23,'Spacing','spacingConfig','global',NULL,NULL,0,'none',NULL,'craft\\fields\\ButtonGroup','{\"customOptions\":false,\"iconsOnly\":false,\"options\":[{\"label\":\"Small\",\"value\":\"small\",\"icon\":\"\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"icon\":\"\",\"default\":\"1\"},{\"label\":\"Large\",\"value\":\"large\",\"icon\":\"\",\"default\":\"\"}]}','2024-12-20 09:09:32','2025-05-26 08:41:27',NULL,'48a3d45e-b4f5-49f2-a960-94adcb851007'),(24,'Target','targetConfig','global',NULL,NULL,0,'none',NULL,'craft\\fields\\ButtonGroup','{\"customOptions\":false,\"iconsOnly\":false,\"options\":[{\"label\":\"Default\",\"value\":\"_self\",\"icon\":\"\",\"default\":\"1\"},{\"label\":\"New Tab\",\"value\":\"_blank\",\"icon\":\"\",\"default\":\"\"}]}','2024-12-20 15:37:16','2025-05-26 08:41:17',NULL,'9711e272-d70a-4399-adde-7368c097f72c'),(25,'Button','buttonField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New button\",\"defaultIndexViewMode\":\"cards\",\"entryTypes\":[\"aa95f819-8179-4afd-8972-f3d4b77f3056\"],\"includeTableView\":false,\"maxEntries\":1,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":true,\"viewMode\":\"cards\"}','2024-12-20 15:43:07','2024-12-20 15:43:07',NULL,'6a670d1f-08c6-4670-a8d8-30615c588e2f'),(26,'Primary navigation','primaryNavigationField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"minEntries\":null,\"maxEntries\":null,\"enableVersioning\":false,\"viewMode\":\"cards\",\"showCardsInGrid\":true,\"includeTableView\":false,\"defaultTableColumns\":[],\"defaultIndexViewMode\":\"cards\",\"pageSize\":50,\"createButtonLabel\":\"New link\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null,\"siteSettings\":{\"e1acd264-0533-4dd7-8cfa-183423e1c25e\":[]},\"entryTypes\":[{\"uid\":\"72688bf2-9dcf-4032-9899-7d39ab1986f0\"}]}','2024-12-20 15:52:44','2025-05-26 09:23:58',NULL,'841b576a-8964-4701-ac7a-8789c2ee20d1'),(27,'Footer navigation','footerNavigationField','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Matrix','{\"createButtonLabel\":\"New link\",\"defaultIndexViewMode\":\"cards\",\"enableVersioning\":false,\"entryTypes\":[{\"uid\":\"72688bf2-9dcf-4032-9899-7d39ab1986f0\"}],\"includeTableView\":false,\"maxEntries\":null,\"minEntries\":null,\"pageSize\":50,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"showCardsInGrid\":true,\"viewMode\":\"cards\"}','2024-12-20 15:54:28','2025-05-26 09:23:35',NULL,'883ee07a-821a-4772-acaf-e9a78ff34015'),(28,'Multiline text','multilineTextField','global',NULL,NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2025-06-17 08:04:48','2025-06-17 08:04:48',NULL,'d0499f4d-e39e-4fab-80c5-595fadbfcf91');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `globalsets` VALUES (2,'Header','header',4,1,'2024-10-11 14:44:15','2024-10-11 14:44:15','a67d48bc-e451-47d9-9b4d-11993da85ee2'),(3,'Footer','footer',5,2,'2024-10-11 14:44:41','2024-10-11 14:44:41','462faf00-5b99-4cd1-b2ba-9fb0321c0ed3');
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2025-03-22 21:25:21','2025-03-22 21:26:28','00e1d9bb-51b9-4ebf-847e-a089feaef726');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqltokens` VALUES (1,'Public Token','__PUBLIC__',0,NULL,NULL,NULL,'2025-03-22 21:26:16','2025-03-22 21:26:16','bd9b3761-818c-47d9-821c-a81423166a72');
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'5.7.10','5.7.0.3',0,'vefhokteeoje','3@pqjmtaxhqt','2024-10-11 09:30:43','2025-06-17 08:06:56','4cf2b2c7-6d1f-4102-b3dc-f37ff41461e2');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','03341c96-ebbc-4f84-bd26-3b6543d15be2'),(2,'craft','m221101_115859_create_entries_authors_table','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','56a05344-1620-4ea2-bde9-69d64ad27662'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','c1dd4c0d-58ea-402b-ac39-4c21ff132851'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','768e3d19-dc44-422a-bd39-1a5ef6c15a7f'),(5,'craft','m230314_110309_add_authenticator_table','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','456cf77f-0c85-4674-b2bf-9db3bfcc2cb7'),(6,'craft','m230314_111234_add_webauthn_table','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','fe8cab2e-044b-4f38-90b3-4397b5871318'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','a7925419-8b16-41b5-a656-76ab473d4bc4'),(8,'craft','m230511_000000_field_layout_configs','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','b0acd88b-d774-4c76-b69a-61380c87299e'),(9,'craft','m230511_215903_content_refactor','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','427c0df5-cad6-44ac-a00b-aa9bd696421a'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','59819392-2d54-4591-b81c-35bb937b604f'),(11,'craft','m230524_000001_entry_type_icons','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','8c750020-4b06-4289-9577-ed1e4f6b6211'),(12,'craft','m230524_000002_entry_type_colors','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','303a890b-688b-481f-a417-e869e863c660'),(13,'craft','m230524_220029_global_entry_types','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','c3a388eb-46d7-41fe-b91f-1325dd238fb8'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','7a4ae6aa-8396-4a5d-84cf-8624ccff7a3d'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','8cba15d5-9f4a-4081-a55b-982f9a966379'),(16,'craft','m230616_173810_kill_field_groups','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','043ba4bd-7112-437c-b7d0-34ab1adbae87'),(17,'craft','m230616_183820_remove_field_name_limit','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','72340efe-c810-4f2f-9ba1-6c6e48516bb1'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','122a8cda-c7f8-44e2-a4a3-3adbc19e4477'),(19,'craft','m230710_162700_element_activity','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','f6b8fe75-d711-4b5f-b2c9-272c4856c802'),(20,'craft','m230820_162023_fix_cache_id_type','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','ce7a4ad5-55e5-4bf6-a3ee-300a23de1f8b'),(21,'craft','m230826_094050_fix_session_id_type','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','51c22c2f-fc58-4529-ab0a-d045ccecb6da'),(22,'craft','m230904_190356_address_fields','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','8fe44172-768a-4b04-aae2-230f674d9122'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','0bba8949-0a0b-4206-a33c-03c841c4a02c'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','fce81bf0-b1d2-4d6b-821a-c6020eb55878'),(25,'craft','m231213_030600_element_bulk_ops','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','dd9f14d4-8784-43c6-967b-3b5b8c42338d'),(26,'craft','m240129_150719_sites_language_amend_length','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','353a9845-d2bb-402e-a8ae-51bd27d9fef5'),(27,'craft','m240206_035135_convert_json_columns','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','4e495f52-f912-4123-bebe-7ef5065f15e1'),(28,'craft','m240207_182452_address_line_3','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','abe53c13-5081-4f79-acb7-57275b7921a2'),(29,'craft','m240302_212719_solo_preview_targets','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','698a3b8e-dfe7-4551-aa07-dc05638538fb'),(30,'craft','m240619_091352_add_auth_2fa_timestamp','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','32e578c1-3fad-4b7e-a203-35d1574fd18a'),(31,'craft','m240723_214330_drop_bulkop_fk','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','93fa32e3-fe1b-4ecc-9576-fdea2a46c62b'),(32,'craft','m240731_053543_soft_delete_fields','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','0f0f1f62-cc31-4e42-933c-1bd1bec54b60'),(33,'craft','m240805_154041_sso_identities','2024-10-11 09:30:44','2024-10-11 09:30:44','2024-10-11 09:30:44','90c07392-fc5b-485a-b8b5-ef4f5c53b949'),(34,'plugin:seo','Install','2024-10-11 13:59:23','2024-10-11 13:59:23','2024-10-11 13:59:23','7419ba32-c689-4af9-95b9-761588ab2638'),(35,'plugin:seo','m180906_152947_add_site_id_to_redirects','2024-10-11 13:59:23','2024-10-11 13:59:23','2024-10-11 13:59:23','5d71b604-2979-402d-b5d9-a92064a4665b'),(36,'plugin:seo','m190114_152300_upgrade_to_new_data_format','2024-10-11 13:59:23','2024-10-11 13:59:23','2024-10-11 13:59:23','2e51bc2a-fe76-4b03-9541-7788125b8ced'),(37,'plugin:seo','m200518_110721_add_order_to_redirects','2024-10-11 13:59:23','2024-10-11 13:59:23','2024-10-11 13:59:23','00b970c1-975d-4863-ab60-1fdbdcaa926e'),(38,'plugin:seo','m201207_124200_add_product_types_to_sitemap','2024-10-11 13:59:23','2024-10-11 13:59:23','2024-10-11 13:59:23','31006670-b127-4bfa-9979-ed63ecf8a2de'),(39,'plugin:ckeditor','Install','2024-10-11 14:02:22','2024-10-11 14:02:22','2024-10-11 14:02:22','0acb2bb8-85cb-472e-94e6-9b7a7df77cfa'),(40,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-10-11 14:02:22','2024-10-11 14:02:22','2024-10-11 14:02:22','3fc16147-bc10-42f4-acc0-043d11b9f5dd'),(41,'craft','m240926_202248_track_entries_deleted_with_section','2024-11-22 21:38:37','2024-11-22 21:38:37','2024-11-22 21:38:37','975700eb-f6c6-45b3-8e50-5640ef391a7d'),(42,'craft','m241120_190905_user_affiliated_sites','2025-03-14 11:19:33','2025-03-14 11:19:33','2025-03-14 11:19:33','86bb0d00-ab0b-433b-9ea3-b7137d92f3ca'),(43,'craft','m241125_122914_add_viewUsers_permission','2025-03-14 11:19:33','2025-03-14 11:19:33','2025-03-14 11:19:33','0ece8ed5-3d8c-47b8-87a9-4825f9709bec'),(44,'craft','m250119_135304_entry_type_overrides','2025-03-14 11:19:33','2025-03-14 11:19:33','2025-03-14 11:19:33','ea599aa5-819b-4329-ac42-f723c2b4bc2d'),(45,'craft','m250206_135036_search_index_queue','2025-04-23 11:14:05','2025-04-23 11:14:05','2025-04-23 11:14:05','023cfabc-166d-4954-9e41-6b7786cccc2a'),(46,'craft','m250207_172349_bulkop_events','2025-04-23 11:14:05','2025-04-23 11:14:05','2025-04-23 11:14:05','46a259fb-2017-4ea5-82d5-a256de350638'),(47,'craft','m250315_131608_unlimited_authors','2025-04-23 11:14:05','2025-04-23 11:14:05','2025-04-23 11:14:05','b8bde341-d1f0-4295-ab24-932962bbecb5'),(48,'craft','m250403_171253_static_statuses','2025-04-23 11:14:05','2025-04-23 11:14:05','2025-04-23 11:14:05','db58ab2e-fd03-4766-ba74-d1eaa961e021');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'seo','5.0.0','3.2.0','2024-10-11 13:59:23','2024-10-11 13:59:23','2024-10-11 13:59:23','74bacb4e-e7b5-4985-b893-df0b3ab16695'),(2,'ckeditor','4.9.0','3.0.0.0','2024-10-11 14:02:22','2024-10-11 14:02:22','2025-05-26 07:36:13','94f8882d-f863-463d-8c2c-0eeb3ff1e937'),(3,'vite','5.0.1','1.0.0','2024-10-25 10:50:18','2024-10-25 10:50:18','2024-10-25 10:50:18','1dff2013-d07b-4a04-9dc9-676c1bab7454'),(4,'cp-field-inspect','2.0.4','1.0.0','2024-11-22 22:30:21','2024-11-22 22:30:21','2025-03-14 11:19:56','30a566cb-b816-4611-981c-b393b561a677');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.headingLevels.0','2'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.headingLevels.1','3'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.headingLevels.2','4'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.headingLevels.3','5'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.headingLevels.4','6'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.name','\"Rich text\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.alignment.options.0','\"left\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.alignment.options.1','\"center\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.alignment.options.2','\"right\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.fontColor.colorPicker','false'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.fontColor.colors.0.color','\"\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.fontColor.colors.0.label','\"\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.link.decorators.openInNewTab.attributes.rel','\"noopener noreferrer\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.link.decorators.openInNewTab.attributes.target','\"_blank\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.link.decorators.openInNewTab.label','\"Open in new tab\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.link.decorators.openInNewTab.mode','\"manual\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.list.properties.reversed','false'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.list.properties.startIndex','false'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.options.list.properties.styles','false'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.0','\"heading\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.1','\"|\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.10','\"numberedList\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.11','\"blockQuote\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.12','\"code\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.13','\"insertTable\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.14','\"|\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.15','\"sourceEditing\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.2','\"bold\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.3','\"italic\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.4','\"underline\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.5','\"strikethrough\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.6','\"link\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.7','\"fontColor\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.8','\"|\"'),('ckeditor.configs.857c718e-b5a7-402c-8bcd-e92b86306176.toolbar.9','\"bulletedList\"'),('ckeditor.configs.8eceae5c-bf72-475b-a84f-33735f3d3f1d.headingLevels','false'),('ckeditor.configs.8eceae5c-bf72-475b-a84f-33735f3d3f1d.name','\"Title\"'),('ckeditor.configs.8eceae5c-bf72-475b-a84f-33735f3d3f1d.toolbar.0','\"bold\"'),('dateModified','1750147616'),('elementSources.craft\\elements\\Asset.0.defaultSort.0','\"dateCreated\"'),('elementSources.craft\\elements\\Asset.0.defaultSort.1','\"desc\"'),('elementSources.craft\\elements\\Asset.0.defaultViewMode','\"\"'),('elementSources.craft\\elements\\Asset.0.disabled','false'),('elementSources.craft\\elements\\Asset.0.key','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.0','\"filename\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.1','\"size\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.2','\"imageSize\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.3','\"kind\"'),('elementSources.craft\\elements\\Asset.0.tableAttributes.4','\"link\"'),('elementSources.craft\\elements\\Asset.0.type','\"native\"'),('elementSources.craft\\elements\\Asset.1.key','\"temp\"'),('elementSources.craft\\elements\\Asset.1.type','\"native\"'),('elementSources.craft\\elements\\Entry.0.defaultSort.0','\"postDate\"'),('elementSources.craft\\elements\\Entry.0.defaultSort.1','\"desc\"'),('elementSources.craft\\elements\\Entry.0.defaultViewMode','\"\"'),('elementSources.craft\\elements\\Entry.0.disabled','true'),('elementSources.craft\\elements\\Entry.0.key','\"*\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.0','\"status\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.1','\"section\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.2','\"postDate\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.3','\"expiryDate\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.4','\"link\"'),('elementSources.craft\\elements\\Entry.0.type','\"native\"'),('elementSources.craft\\elements\\Entry.1.defaultSort.0','\"title\"'),('elementSources.craft\\elements\\Entry.1.defaultSort.1','\"asc\"'),('elementSources.craft\\elements\\Entry.1.defaultViewMode','\"\"'),('elementSources.craft\\elements\\Entry.1.disabled','true'),('elementSources.craft\\elements\\Entry.1.key','\"singles\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.0','\"status\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.1','\"link\"'),('elementSources.craft\\elements\\Entry.1.type','\"native\"'),('elementSources.craft\\elements\\Entry.2.heading','\"General\"'),('elementSources.craft\\elements\\Entry.2.type','\"heading\"'),('elementSources.craft\\elements\\Entry.3.condition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('elementSources.craft\\elements\\Entry.3.condition.conditionRules.0.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\SectionConditionRule\"'),('elementSources.craft\\elements\\Entry.3.condition.conditionRules.0.operator','\"in\"'),('elementSources.craft\\elements\\Entry.3.condition.conditionRules.0.uid','\"2d9c68f9-41eb-4405-b070-1542e1b3bfd5\"'),('elementSources.craft\\elements\\Entry.3.condition.conditionRules.0.values.0','\"5b185af0-6204-4ae7-8d25-bf9ef8208ad0\"'),('elementSources.craft\\elements\\Entry.3.condition.elementType','\"craft\\\\elements\\\\Entry\"'),('elementSources.craft\\elements\\Entry.3.condition.fieldContext','\"global\"'),('elementSources.craft\\elements\\Entry.3.defaultSort.0','\"title\"'),('elementSources.craft\\elements\\Entry.3.defaultSort.1','\"asc\"'),('elementSources.craft\\elements\\Entry.3.defaultViewMode','\"table\"'),('elementSources.craft\\elements\\Entry.3.key','\"custom:04fa9561-5f43-4a9c-bc6e-68cce3b05fd2\"'),('elementSources.craft\\elements\\Entry.3.label','\"Default pages\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.0','\"uri\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.1','\"dateUpdated\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.2','\"status\"'),('elementSources.craft\\elements\\Entry.3.type','\"custom\"'),('elementSources.craft\\elements\\Entry.4.defaultSort.0','\"structure\"'),('elementSources.craft\\elements\\Entry.4.defaultSort.1','\"asc\"'),('elementSources.craft\\elements\\Entry.4.defaultViewMode','\"\"'),('elementSources.craft\\elements\\Entry.4.disabled','false'),('elementSources.craft\\elements\\Entry.4.key','\"section:eb0d0935-3bc1-4cf1-86d9-275a753716de\"'),('elementSources.craft\\elements\\Entry.4.tableAttributes.0','\"uri\"'),('elementSources.craft\\elements\\Entry.4.tableAttributes.1','\"dateUpdated\"'),('elementSources.craft\\elements\\Entry.4.tableAttributes.2','\"status\"'),('elementSources.craft\\elements\\Entry.4.type','\"native\"'),('email.fromEmail','\"web@digitalastronaut.be\"'),('email.fromName','\"craft-boilerplate\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.color','\"teal\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.cardView.0','\"layoutElement:4fb1eda8-5465-4a7b-98e6-5b49864eb261\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.cardView.1','\"layoutElement:a3bd6039-d017-40d2-9bab-04c8f6ac8ae6\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elementCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.dateAdded','\"2024-12-20T15:39:14+00:00\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.elementCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.fieldUid','\"a3045613-418c-483e-a666-fb4269b18c80\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.handle','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.includeInCards','true'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.instructions','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.label','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.providesThumbs','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.required','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.tip','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.uid','\"a3bd6039-d017-40d2-9bab-04c8f6ac8ae6\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.userCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.warning','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.0.width','100'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.dateAdded','\"2024-12-20T15:39:14+00:00\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.elementCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.fieldUid','\"4381ddb2-8940-4d25-8e42-5a770b533b71\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.handle','\"labelField\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.includeInCards','true'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.instructions','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.label','\"Label\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.providesThumbs','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.required','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.tip','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.uid','\"4fb1eda8-5465-4a7b-98e6-5b49864eb261\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.userCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.warning','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.1.width','100'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.dateAdded','\"2024-12-20T15:39:14+00:00\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.elementCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.fieldUid','\"9711e272-d70a-4399-adde-7368c097f72c\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.handle','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.includeInCards','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.instructions','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.label','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.providesThumbs','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.required','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.tip','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.uid','\"c867ed4f-178c-4a4f-a835-f9ed45853d25\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.userCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.warning','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.elements.2.width','100'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.name','\"Content\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.uid','\"eeab1e9b-c818-450f-b80a-ca21270a363a\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.fieldLayouts.dc21ca45-42ec-4391-89d5-94412375ad8e.tabs.0.userCondition','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.handle','\"link\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.hasTitleField','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.icon','\"link\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.name','\"Link\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.showSlugField','false'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.showStatusField','true'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.slugTranslationKeyFormat','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.slugTranslationMethod','\"site\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.titleFormat','\"\"'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.titleTranslationKeyFormat','null'),('entryTypes.28efc0ec-8432-4ee6-b8ad-5b109779166c.titleTranslationMethod','\"site\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.color','\"sky\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elementCondition','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.dateAdded','\"2024-11-22T22:00:54+00:00\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.elementCondition','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.fieldUid','\"d1ab0c28-7124-4171-99dd-27b8f9805017\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.handle','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.includeInCards','false'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.instructions','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.label','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.providesThumbs','false'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.required','false'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.tip','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.uid','\"c5081a8a-b23c-437a-adf6-b340842dbcb2\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.userCondition','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.warning','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.elements.0.width','100'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.name','\"Content\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.uid','\"a9f5033b-447d-4c23-97f7-156ad2bf1fda\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.fieldLayouts.5544227c-de0f-4abd-9b19-625fed60111d.tabs.0.userCondition','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.handle','\"text\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.hasTitleField','false'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.icon','\"text\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.name','\"Text\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.showSlugField','false'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.showStatusField','true'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.slugTranslationKeyFormat','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.slugTranslationMethod','\"site\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.titleFormat','\"\"'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.titleTranslationKeyFormat','null'),('entryTypes.704846e3-cfa0-4a1f-8f8f-f65b73c9de47.titleTranslationMethod','\"site\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.color','\"teal\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.cardView.0','\"layoutElement:40ed50a6-3625-4738-bc83-38cfb5c7856c\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.cardView.1','\"layoutElement:7b6b8d88-d146-4b44-87b7-d226061a4ba2\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elementCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.dateAdded','\"2024-12-20T15:52:24+00:00\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.editCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.elementCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.fieldUid','\"a3045613-418c-483e-a666-fb4269b18c80\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.handle','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.includeInCards','true'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.instructions','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.label','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.providesThumbs','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.required','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.tip','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.uid','\"7b6b8d88-d146-4b44-87b7-d226061a4ba2\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.userCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.warning','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.0.width','100'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.dateAdded','\"2024-12-20T15:52:24+00:00\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.editCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.elementCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.fieldUid','\"4381ddb2-8940-4d25-8e42-5a770b533b71\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.handle','\"labelField\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.includeInCards','true'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.instructions','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.label','\"Label\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.providesThumbs','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.required','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.tip','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.uid','\"40ed50a6-3625-4738-bc83-38cfb5c7856c\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.userCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.warning','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.1.width','100'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.dateAdded','\"2024-12-20T15:52:24+00:00\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.editCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.elementCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.fieldUid','\"9711e272-d70a-4399-adde-7368c097f72c\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.handle','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.includeInCards','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.instructions','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.label','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.providesThumbs','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.required','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.tip','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.uid','\"420f6282-22bb-49d5-ad53-634acb1e6386\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.userCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.warning','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.2.width','100'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.dateAdded','\"2024-12-20T15:52:24+00:00\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.editCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.elementCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.fieldUid','\"2ab57b6f-1852-449c-9afa-30c833317b58\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.handle','\"subLinksField\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.includeInCards','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.instructions','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.label','\"Sub Links\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.providesThumbs','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.required','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.tip','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.uid','\"18d1e987-82c9-4983-94e9-d529a8d6525a\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.userCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.warning','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.elements.3.width','100'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.name','\"Content\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.uid','\"8a293e0e-f3b3-42fe-a621-30fb3ffc255e\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.fieldLayouts.3053f7ed-f04f-4f24-bd03-7a1dccd1388c.tabs.0.userCondition','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.handle','\"linkMenu\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.hasTitleField','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.icon','\"link\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.name','\"Link menu\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.showSlugField','false'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.showStatusField','true'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.slugTranslationKeyFormat','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.slugTranslationMethod','\"site\"'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.titleFormat','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.titleTranslationKeyFormat','null'),('entryTypes.72688bf2-9dcf-4032-9899-7d39ab1986f0.titleTranslationMethod','\"site\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.color','\"teal\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.cardView.0','\"layoutElement:c4f16b55-1f41-401a-b093-f360e013fbe0\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.cardView.1','\"layoutElement:17c79c1b-dba6-4c1e-8db3-6d3aaabfaa91\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elementCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.dateAdded','\"2024-12-20T15:38:33+00:00\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.elementCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.fieldUid','\"a3045613-418c-483e-a666-fb4269b18c80\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.handle','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.includeInCards','true'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.instructions','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.label','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.providesThumbs','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.required','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.tip','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.uid','\"17c79c1b-dba6-4c1e-8db3-6d3aaabfaa91\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.userCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.warning','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.0.width','100'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.dateAdded','\"2024-12-20T15:38:33+00:00\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.elementCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.fieldUid','\"4381ddb2-8940-4d25-8e42-5a770b533b71\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.handle','\"labelField\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.includeInCards','true'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.instructions','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.label','\"Label\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.providesThumbs','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.required','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.tip','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.uid','\"c4f16b55-1f41-401a-b093-f360e013fbe0\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.userCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.warning','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.1.width','100'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.dateAdded','\"2024-12-20T15:38:33+00:00\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.elementCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.fieldUid','\"9711e272-d70a-4399-adde-7368c097f72c\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.handle','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.includeInCards','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.instructions','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.label','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.providesThumbs','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.required','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.tip','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.uid','\"5282cba7-8acf-46e1-b231-89a9ec58e01b\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.userCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.warning','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.2.width','100'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.dateAdded','\"2024-11-22T21:49:51+00:00\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.elementCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.fieldUid','\"7947a42a-167a-4d11-a4c2-dcf9fa46eb65\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.handle','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.includeInCards','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.instructions','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.label','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.providesThumbs','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.required','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.tip','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.uid','\"084fd2e5-6bb1-4d5f-92a6-c10e55c57308\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.userCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.warning','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.elements.3.width','100'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.name','\"Content\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.uid','\"f9e1cc15-c079-4dcd-95e2-2d2d9a1aa357\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.fieldLayouts.5729310c-3ea6-42f8-8947-2566188bb614.tabs.0.userCondition','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.handle','\"button\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.hasTitleField','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.icon','\"square\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.name','\"Button\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.showSlugField','false'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.showStatusField','true'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.slugTranslationKeyFormat','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.slugTranslationMethod','\"site\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.titleFormat','\"\"'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.titleTranslationKeyFormat','null'),('entryTypes.aa95f819-8179-4afd-8972-f3d4b77f3056.titleTranslationMethod','\"site\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.color','\"sky\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elementCondition','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.dateAdded','\"2024-12-20T09:10:36+00:00\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.elementCondition','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.fieldUid','\"48a3d45e-b4f5-49f2-a960-94adcb851007\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.handle','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.includeInCards','false'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.instructions','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.label','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.providesThumbs','false'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.required','false'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.tip','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.uid','\"a4c0a2a1-4545-44dc-b3c3-a1ddb151aade\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.userCondition','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.warning','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.elements.0.width','100'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.name','\"Content\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.uid','\"12ce648f-f124-4712-a239-fea8b1b4fc0a\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.fieldLayouts.c53f3b56-8817-468f-bd56-2bff7a3319bd.tabs.0.userCondition','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.handle','\"spacing\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.hasTitleField','false'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.icon','\"up-right-and-down-left-from-center\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.name','\"Spacing\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.showSlugField','false'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.showStatusField','true'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.slugTranslationKeyFormat','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.slugTranslationMethod','\"site\"'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.titleFormat','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.titleTranslationKeyFormat','null'),('entryTypes.ca6f639a-12fb-4ecd-8e43-1c9b5e863711.titleTranslationMethod','\"site\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.color','\"violet\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elementCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.autocapitalize','true'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.autocomplete','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.autocorrect','true'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.class','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.dateAdded','\"2024-10-11T14:49:52+00:00\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.disabled','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.elementCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.id','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.includeInCards','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.inputType','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.instructions','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.label','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.max','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.min','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.name','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.orientation','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.placeholder','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.providesThumbs','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.readonly','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.required','true'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.size','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.step','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.tip','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.title','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.uid','\"8e99c3f8-8947-45b5-bd0c-b31135dbe136\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.userCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.warning','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.0.width','100'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.dateAdded','\"2024-10-11T15:06:26+00:00\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.elementCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.fieldUid','\"23bc0810-e9d7-499e-8398-83de3788b62c\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.handle','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.includeInCards','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.instructions','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.label','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.providesThumbs','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.required','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.tip','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.uid','\"7f96e298-8f7d-4fe5-a49d-5cc2f976c676\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.userCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.warning','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.elements.1.width','100'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.name','\"Content\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.uid','\"0e27f7e0-2bd5-4aa3-b416-8d1f60607845\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.0.userCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elementCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.dateAdded','\"2024-11-13T14:19:35+00:00\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.elementCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.fieldUid','\"4b9c49b3-1c60-4cf8-90ea-24baf113c4ee\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.handle','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.includeInCards','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.instructions','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.label','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.providesThumbs','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.required','false'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.tip','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.uid','\"29fcd495-2a8f-498b-992c-d481dd7f72f5\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.userCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.warning','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.elements.0.width','100'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.name','\"SEO\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.uid','\"0c63d3c5-ccc3-482b-926e-3bc3cefec74c\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.fieldLayouts.ccf03281-b22e-457e-8e71-37332ee99ce8.tabs.1.userCondition','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.handle','\"page\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.hasTitleField','true'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.icon','\"file\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.name','\"Page\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.showSlugField','true'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.showStatusField','true'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.slugTranslationKeyFormat','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.slugTranslationMethod','\"site\"'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.titleFormat','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.titleTranslationKeyFormat','null'),('entryTypes.d7e8d0bc-8052-499d-99b8-d622687dfee7.titleTranslationMethod','\"site\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.columnSuffix','null'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.handle','\"linkField\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.instructions','null'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.name','\"Link\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.searchable','true'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.createButtonLabel','\"New link\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.defaultIndexViewMode','\"cards\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.entryTypes.0','\"28efc0ec-8432-4ee6-b8ad-5b109779166c\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.includeTableView','false'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.maxEntries','1'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.minEntries','null'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.pageSize','50'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.propagationKeyFormat','null'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.propagationMethod','\"all\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.showCardsInGrid','true'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.settings.viewMode','\"cards\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.translationKeyFormat','null'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.translationMethod','\"site\"'),('fields.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a.type','\"craft\\\\fields\\\\Matrix\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.columnSuffix','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.handle','\"blocksField\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.instructions','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.name','\"Blocks\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.searchable','true'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.createButtonLabel','\"New Block\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.defaultIndexViewMode','\"cards\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.entryTypes.0','\"704846e3-cfa0-4a1f-8f8f-f65b73c9de47\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.entryTypes.1','\"ca6f639a-12fb-4ecd-8e43-1c9b5e863711\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.includeTableView','false'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.maxEntries','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.minEntries','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.pageSize','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.propagationKeyFormat','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.propagationMethod','\"all\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.showCardsInGrid','false'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.settings.viewMode','\"blocks\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.translationKeyFormat','null'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.translationMethod','\"site\"'),('fields.23bc0810-e9d7-499e-8398-83de3788b62c.type','\"craft\\\\fields\\\\Matrix\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.columnSuffix','null'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.handle','\"linksField\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.instructions','null'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.name','\"Links\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.searchable','true'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.createButtonLabel','\"New link\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.defaultIndexViewMode','\"cards\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.enableVersioning','false'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.entryTypes.0.__assoc__.0.1','\"28efc0ec-8432-4ee6-b8ad-5b109779166c\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.includeTableView','false'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.maxEntries','null'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.minEntries','null'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.pageSize','50'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.propagationKeyFormat','null'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.propagationMethod','\"all\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.showCardsInGrid','true'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.settings.viewMode','\"cards\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.translationKeyFormat','null'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.translationMethod','\"site\"'),('fields.2ab57b6f-1852-449c-9afa-30c833317b58.type','\"craft\\\\fields\\\\Matrix\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.columnSuffix','null'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.handle','\"iconField\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.instructions','null'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.name','\"Icon\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.searchable','false'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.customOptions','false'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.options.0.__assoc__.0.0','\"label\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.options.0.__assoc__.0.1','\"None\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.options.0.__assoc__.1.0','\"value\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.options.0.__assoc__.1.1','\"\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.options.0.__assoc__.2.0','\"default\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.settings.options.0.__assoc__.2.1','\"1\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.translationKeyFormat','null'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.translationMethod','\"none\"'),('fields.2b9c20b9-9252-416a-b5a0-041473c84c8a.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.columnSuffix','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.handle','\"imagesField\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.instructions','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.name','\"Images\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.searchable','true'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.allowedKinds.0','\"image\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.allowSelfRelations','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.allowSubfolders','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.allowUploads','true'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.branchLimit','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.defaultUploadLocationSource','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.defaultUploadLocationSubpath','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.maintainHierarchy','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.maxRelations','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.minRelations','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.previewMode','\"full\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.restrictedDefaultUploadSubpath','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.restrictedLocationSource','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.restrictedLocationSubpath','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.restrictFiles','true'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.restrictLocation','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.selectionLabel','\"Add image\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.showCardsInGrid','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.showSiteMenu','true'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.showUnpermittedFiles','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.showUnpermittedVolumes','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.sources.0','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.targetSiteId','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.validateRelatedElements','false'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.settings.viewMode','\"large\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.translationKeyFormat','null'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.translationMethod','\"none\"'),('fields.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe.type','\"craft\\\\fields\\\\Assets\"'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.columnSuffix','null'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.handle','\"textField\"'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.instructions','null'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.name','\"Text\"'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.searchable','true'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.byteLimit','null'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.charLimit','null'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.code','false'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.initialRows','4'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.multiline','false'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.placeholder','null'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.settings.uiMode','\"normal\"'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.translationKeyFormat','null'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.translationMethod','\"none\"'),('fields.4381ddb2-8940-4d25-8e42-5a770b533b71.type','\"craft\\\\fields\\\\PlainText\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.columnSuffix','null'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.handle','\"buttonsField\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.instructions','null'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.name','\"Buttons\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.searchable','true'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.createButtonLabel','\"New button\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.defaultIndexViewMode','\"cards\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.entryTypes.0','\"aa95f819-8179-4afd-8972-f3d4b77f3056\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.includeTableView','false'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.maxEntries','null'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.minEntries','null'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.pageSize','50'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.propagationKeyFormat','null'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.propagationMethod','\"all\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.showCardsInGrid','true'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.settings.viewMode','\"cards\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.translationKeyFormat','null'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.translationMethod','\"site\"'),('fields.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad.type','\"craft\\\\fields\\\\Matrix\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.columnSuffix','null'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.handle','\"spacingConfig\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.instructions','null'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.name','\"Spacing\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.searchable','false'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.customOptions','false'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.iconsOnly','false'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.0.0','\"label\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.0.1','\"Small\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.1.0','\"value\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.1.1','\"small\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.2.0','\"icon\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.2.1','\"\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.3.0','\"default\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.0.__assoc__.3.1','\"\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.0.0','\"label\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.0.1','\"Medium\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.1.0','\"value\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.1.1','\"medium\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.2.0','\"icon\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.2.1','\"\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.3.0','\"default\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.1.__assoc__.3.1','\"1\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.0.0','\"label\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.0.1','\"Large\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.1.0','\"value\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.1.1','\"large\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.2.0','\"icon\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.2.1','\"\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.3.0','\"default\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.settings.options.2.__assoc__.3.1','\"\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.translationKeyFormat','null'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.translationMethod','\"none\"'),('fields.48a3d45e-b4f5-49f2-a960-94adcb851007.type','\"craft\\\\fields\\\\ButtonGroup\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.columnSuffix','null'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.handle','\"seo\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.instructions','null'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.name','\"SEO\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.searchable','true'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.description','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.hideSocial','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.robots.0','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.robots.1','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.robots.2','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.robots.3','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.robots.4','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.robots.5','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.socialImage','\"\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.suffixAsPrefix','null'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.0.__assoc__.0.0','\"key\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.0.__assoc__.0.1','\"1\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.0.__assoc__.1.0','\"locked\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.0.__assoc__.1.1','\"0\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.0.__assoc__.2.0','\"template\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.0.__assoc__.2.1','\"{title}\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.1.__assoc__.0.0','\"key\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.1.__assoc__.0.1','\"2\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.1.__assoc__.1.0','\"locked\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.1.__assoc__.1.1','\"1\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.1.__assoc__.2.0','\"template\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.title.1.__assoc__.2.1','\" - {{ siteName }}\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.settings.titleSuffix','null'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.translationKeyFormat','null'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.translationMethod','\"none\"'),('fields.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee.type','\"ether\\\\seo\\\\fields\\\\SeoField\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.columnSuffix','null'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.handle','\"buttonField\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.instructions','null'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.name','\"Button\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.searchable','true'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.createButtonLabel','\"New button\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.defaultIndexViewMode','\"cards\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.entryTypes.0','\"aa95f819-8179-4afd-8972-f3d4b77f3056\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.includeTableView','false'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.maxEntries','1'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.minEntries','null'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.pageSize','50'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.propagationKeyFormat','null'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.propagationMethod','\"all\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.showCardsInGrid','true'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.settings.viewMode','\"cards\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.translationKeyFormat','null'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.translationMethod','\"site\"'),('fields.6a670d1f-08c6-4670-a8d8-30615c588e2f.type','\"craft\\\\fields\\\\Matrix\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.columnSuffix','null'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.handle','\"buttonVariantConfig\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.instructions','null'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.name','\"Button variant\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.searchable','false'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.customOptions','false'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.iconsOnly','false'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.0.0','\"label\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.0.1','\"Primary\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.1.0','\"value\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.1.1','\"primary\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.2.0','\"icon\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.2.1','\"\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.3.0','\"default\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.0.__assoc__.3.1','\"1\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.0.0','\"label\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.0.1','\"Secondary\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.1.0','\"value\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.1.1','\"secondary\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.2.0','\"icon\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.2.1','\"\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.3.0','\"default\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.settings.options.1.__assoc__.3.1','\"\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.translationKeyFormat','null'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.translationMethod','\"none\"'),('fields.7947a42a-167a-4d11-a4c2-dcf9fa46eb65.type','\"craft\\\\fields\\\\ButtonGroup\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.columnSuffix','null'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.handle','\"primaryNavigationField\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.instructions','null'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.name','\"Primary navigation\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.searchable','true'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.createButtonLabel','\"New link\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.defaultIndexViewMode','\"cards\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.enableVersioning','false'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.entryTypes.0.__assoc__.0.1','\"72688bf2-9dcf-4032-9899-7d39ab1986f0\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.includeTableView','false'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.maxEntries','null'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.minEntries','null'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.pageSize','50'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.propagationKeyFormat','null'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.propagationMethod','\"all\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.showCardsInGrid','true'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.settings.viewMode','\"cards\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.translationKeyFormat','null'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.translationMethod','\"site\"'),('fields.841b576a-8964-4701-ac7a-8789c2ee20d1.type','\"craft\\\\fields\\\\Matrix\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.columnSuffix','null'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.handle','\"footerNavigationField\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.instructions','null'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.name','\"Footer navigation\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.searchable','true'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.createButtonLabel','\"New link\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.defaultIndexViewMode','\"cards\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.enableVersioning','false'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.entryTypes.0.__assoc__.0.0','\"uid\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.entryTypes.0.__assoc__.0.1','\"72688bf2-9dcf-4032-9899-7d39ab1986f0\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.includeTableView','false'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.maxEntries','null'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.minEntries','null'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.pageSize','50'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.propagationKeyFormat','null'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.propagationMethod','\"all\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.showCardsInGrid','true'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.settings.viewMode','\"cards\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.translationKeyFormat','null'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.translationMethod','\"site\"'),('fields.883ee07a-821a-4772-acaf-e9a78ff34015.type','\"craft\\\\fields\\\\Matrix\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.columnSuffix','null'),('fields.9711e272-d70a-4399-adde-7368c097f72c.handle','\"targetConfig\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.instructions','null'),('fields.9711e272-d70a-4399-adde-7368c097f72c.name','\"Target\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.searchable','false'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.customOptions','false'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.iconsOnly','false'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.0.0','\"label\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.0.1','\"Default\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.1.0','\"value\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.1.1','\"_self\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.2.0','\"icon\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.2.1','\"\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.3.0','\"default\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.0.__assoc__.3.1','\"1\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.0.0','\"label\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.0.1','\"New Tab\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.1.0','\"value\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.1.1','\"_blank\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.2.0','\"icon\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.2.1','\"\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.3.0','\"default\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.settings.options.1.__assoc__.3.1','\"\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.translationKeyFormat','null'),('fields.9711e272-d70a-4399-adde-7368c097f72c.translationMethod','\"none\"'),('fields.9711e272-d70a-4399-adde-7368c097f72c.type','\"craft\\\\fields\\\\ButtonGroup\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.columnSuffix','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.handle','\"imageField\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.instructions','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.name','\"Image\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.searchable','true'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.allowedKinds.0','\"image\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.allowSelfRelations','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.allowSubfolders','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.allowUploads','true'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.branchLimit','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.defaultPlacement','\"end\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.defaultUploadLocationSource','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.defaultUploadLocationSubpath','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.maintainHierarchy','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.maxRelations','1'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.minRelations','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.previewMode','\"full\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.restrictedDefaultUploadSubpath','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.restrictedLocationSource','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.restrictedLocationSubpath','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.restrictFiles','true'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.restrictLocation','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.selectionLabel','\"Add image\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.showCardsInGrid','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.showSiteMenu','true'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.showUnpermittedFiles','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.showUnpermittedVolumes','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.sources.0','\"volume:78f386d8-ccbe-4fa9-b24b-f527005175e6\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.targetSiteId','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.validateRelatedElements','false'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.settings.viewMode','\"large\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.translationKeyFormat','null'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.translationMethod','\"none\"'),('fields.9a80c602-8f9a-47fa-9f77-bec83a7c2418.type','\"craft\\\\fields\\\\Assets\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.columnSuffix','null'),('fields.a3045613-418c-483e-a666-fb4269b18c80.handle','\"urlField\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.instructions','null'),('fields.a3045613-418c-483e-a666-fb4269b18c80.name','\"URL\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.searchable','true'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.maxLength','255'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.showLabelField','false'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.showTargetField','false'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.types.0','\"entry\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.types.1','\"url\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.types.2','\"asset\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.types.3','\"email\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.0.0','\"entry\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.0.1.__assoc__.0.0','\"sources\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.0.1.__assoc__.0.1','\"*\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.1.0','\"url\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.1.1.__assoc__.0.0','\"allowRootRelativeUrls\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.1.1.__assoc__.0.1','\"\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.1.1.__assoc__.1.0','\"allowAnchors\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.1.1.__assoc__.1.1','\"\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.0','\"asset\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.0.0','\"sources\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.0.1','\"*\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.1.0','\"allowedKinds\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.1.1.0','\"image\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.1.1.1','\"pdf\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.2.0','\"showUnpermittedVolumes\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.2.1','\"\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.3.0','\"showUnpermittedFiles\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.settings.typeSettings.__assoc__.2.1.__assoc__.3.1','\"\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.translationKeyFormat','null'),('fields.a3045613-418c-483e-a666-fb4269b18c80.translationMethod','\"none\"'),('fields.a3045613-418c-483e-a666-fb4269b18c80.type','\"craft\\\\fields\\\\Link\"'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.columnSuffix','null'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.handle','\"multilineTextField\"'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.instructions','null'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.name','\"Multiline text\"'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.searchable','true'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.byteLimit','null'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.charLimit','null'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.code','false'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.initialRows','4'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.multiline','true'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.placeholder','null'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.settings.uiMode','\"normal\"'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.translationKeyFormat','null'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.translationMethod','\"none\"'),('fields.d0499f4d-e39e-4fab-80c5-595fadbfcf91.type','\"craft\\\\fields\\\\PlainText\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.columnSuffix','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.handle','\"richTextField\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.instructions','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.name','\"Rich Text\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.searchable','true'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.availableTransforms','\"\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.availableVolumes','\"\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.characterLimit','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.ckeConfig','\"857c718e-b5a7-402c-8bcd-e92b86306176\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.createButtonLabel','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.defaultTransform','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.expandEntryButtons','false'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.fullGraphqlData','false'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.parseEmbeds','false'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.purifierConfig','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.purifyHtml','true'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.showUnpermittedFiles','false'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.showUnpermittedVolumes','false'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.showWordCount','true'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.sourceEditingGroups.0','\"__ADMINS__\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.settings.wordLimit','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.translationKeyFormat','null'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.translationMethod','\"none\"'),('fields.d1ab0c28-7124-4171-99dd-27b8f9805017.type','\"craft\\\\ckeditor\\\\Field\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.columnSuffix','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.handle','\"titleField\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.instructions','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.name','\"Title\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.searchable','true'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.availableTransforms','\"\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.availableVolumes','\"*\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.ckeConfig','\"8eceae5c-bf72-475b-a84f-33735f3d3f1d\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.createButtonLabel','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.defaultTransform','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.enableSourceEditingForNonAdmins','false'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.purifierConfig','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.purifyHtml','true'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.showUnpermittedFiles','false'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.showUnpermittedVolumes','false'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.showWordCount','true'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.settings.wordLimit','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.translationKeyFormat','null'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.translationMethod','\"none\"'),('fields.e7f650f0-adf2-4ec9-95af-8db8542b1931.type','\"craft\\\\ckeditor\\\\Field\"'),('fs.publicFilesystem.hasUrls','true'),('fs.publicFilesystem.name','\"public\"'),('fs.publicFilesystem.settings.path','\"@webroot/uploads\"'),('fs.publicFilesystem.type','\"craft\\\\fs\\\\Local\"'),('fs.publicFilesystem.url','\"$PRIMARY_SITE_URL/uploads\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elementCondition','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.dateAdded','\"2024-12-20T15:54:36+00:00\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.elementCondition','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.fieldUid','\"883ee07a-821a-4772-acaf-e9a78ff34015\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.handle','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.includeInCards','false'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.instructions','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.label','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.providesThumbs','false'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.required','false'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.tip','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.uid','\"ae41e94b-adee-43e0-a814-1430576a90f9\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.userCondition','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.warning','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.elements.0.width','100'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.name','\"Content\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.uid','\"3a08dc35-eb7f-4b71-8bc7-14416fe5cbd2\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.fieldLayouts.4ad04a6b-7b44-407d-ab92-92a537da1d67.tabs.0.userCondition','null'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.handle','\"footer\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.name','\"Footer\"'),('globalSets.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3.sortOrder','2'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elementCondition','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.dateAdded','\"2024-12-20T15:53:26+00:00\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.elementCondition','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.fieldUid','\"841b576a-8964-4701-ac7a-8789c2ee20d1\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.handle','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.includeInCards','false'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.instructions','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.label','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.providesThumbs','false'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.required','false'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.tip','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.uid','\"5940cf61-a6d8-4d9a-ad83-5a1764498066\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.userCondition','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.warning','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.elements.0.width','100'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.name','\"Content\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.uid','\"a8ca7c72-d6ae-4d36-8f15-8514326596e0\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.fieldLayouts.bb5c7841-023c-4e25-aff2-a3bec954e85a.tabs.0.userCondition','null'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.handle','\"header\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.name','\"Header\"'),('globalSets.a67d48bc-e451-47d9-9b4d-11993da85ee2.sortOrder','1'),('graphql.publicToken.enabled','false'),('graphql.publicToken.expiryDate','null'),('graphql.schemas.00e1d9bb-51b9-4ebf-847e-a089feaef726.isPublic','true'),('graphql.schemas.00e1d9bb-51b9-4ebf-847e-a089feaef726.name','\"Public Schema\"'),('meta.__names__.00e1d9bb-51b9-4ebf-847e-a089feaef726','\"Public Schema\"'),('meta.__names__.05248eae-0d0d-4c9b-9c0f-da2e1ec1213a','\"Link\"'),('meta.__names__.23bc0810-e9d7-499e-8398-83de3788b62c','\"Blocks\"'),('meta.__names__.28efc0ec-8432-4ee6-b8ad-5b109779166c','\"Link\"'),('meta.__names__.2ab57b6f-1852-449c-9afa-30c833317b58','\"Links\"'),('meta.__names__.2b9c20b9-9252-416a-b5a0-041473c84c8a','\"Icon\"'),('meta.__names__.39dae8e0-9ae7-4d95-9088-aa5a0af11cbe','\"Images\"'),('meta.__names__.4381ddb2-8940-4d25-8e42-5a770b533b71','\"Text\"'),('meta.__names__.462faf00-5b99-4cd1-b2ba-9fb0321c0ed3','\"Footer\"'),('meta.__names__.4873bc46-6c2c-4e5a-8e84-cb8e312f20ad','\"Buttons\"'),('meta.__names__.48a3d45e-b4f5-49f2-a960-94adcb851007','\"Spacing\"'),('meta.__names__.4b9c49b3-1c60-4cf8-90ea-24baf113c4ee','\"SEO\"'),('meta.__names__.5b185af0-6204-4ae7-8d25-bf9ef8208ad0','\"Home\"'),('meta.__names__.6a670d1f-08c6-4670-a8d8-30615c588e2f','\"Button\"'),('meta.__names__.704846e3-cfa0-4a1f-8f8f-f65b73c9de47','\"Text\"'),('meta.__names__.72688bf2-9dcf-4032-9899-7d39ab1986f0','\"Link menu\"'),('meta.__names__.78f386d8-ccbe-4fa9-b24b-f527005175e6','\"uploads\"'),('meta.__names__.7947a42a-167a-4d11-a4c2-dcf9fa46eb65','\"Button variant\"'),('meta.__names__.841b576a-8964-4701-ac7a-8789c2ee20d1','\"Primary navigation\"'),('meta.__names__.857c718e-b5a7-402c-8bcd-e92b86306176','\"Rich text\"'),('meta.__names__.883ee07a-821a-4772-acaf-e9a78ff34015','\"Footer navigation\"'),('meta.__names__.8ec97a19-2e28-4350-b8a9-78fc2b8a06e2','\"craft-boilerplate\"'),('meta.__names__.8eceae5c-bf72-475b-a84f-33735f3d3f1d','\"Title\"'),('meta.__names__.9711e272-d70a-4399-adde-7368c097f72c','\"Target\"'),('meta.__names__.9a80c602-8f9a-47fa-9f77-bec83a7c2418','\"Image\"'),('meta.__names__.a3045613-418c-483e-a666-fb4269b18c80','\"URL\"'),('meta.__names__.a67d48bc-e451-47d9-9b4d-11993da85ee2','\"Header\"'),('meta.__names__.aa95f819-8179-4afd-8972-f3d4b77f3056','\"Button\"'),('meta.__names__.ca6f639a-12fb-4ecd-8e43-1c9b5e863711','\"Spacing\"'),('meta.__names__.d0499f4d-e39e-4fab-80c5-595fadbfcf91','\"Multiline text\"'),('meta.__names__.d1ab0c28-7124-4171-99dd-27b8f9805017','\"Rich Text\"'),('meta.__names__.d7e8d0bc-8052-499d-99b8-d622687dfee7','\"Page\"'),('meta.__names__.e1acd264-0533-4dd7-8cfa-183423e1c25e','\"craft-boilerplate\"'),('meta.__names__.e7f650f0-adf2-4ec9-95af-8db8542b1931','\"Title\"'),('meta.__names__.eb0d0935-3bc1-4cf1-86d9-275a753716de','\"Extra Pages\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.cp-field-inspect.edition','\"standard\"'),('plugins.cp-field-inspect.enabled','true'),('plugins.cp-field-inspect.schemaVersion','\"1.0.0\"'),('plugins.seo.edition','\"standard\"'),('plugins.seo.enabled','true'),('plugins.seo.schemaVersion','\"3.2.0\"'),('plugins.seo.settings.description','\"\"'),('plugins.seo.settings.facebookAppId','\"\"'),('plugins.seo.settings.metaTemplate','\"\"'),('plugins.seo.settings.removeAlternateUrls','\"\"'),('plugins.seo.settings.robots.0','\"\"'),('plugins.seo.settings.robots.1','\"\"'),('plugins.seo.settings.robots.2','\"\"'),('plugins.seo.settings.robots.3','\"\"'),('plugins.seo.settings.robots.4','\"\"'),('plugins.seo.settings.robots.5','\"\"'),('plugins.seo.settings.robotsTxt','\"{# Sitemap URL #}\\r\\nSitemap: {{ url(seo.sitemapName ~ \'.xml\') }}\\r\\n\\r\\n{# Disallows #}\\r\\n{% if craft.app.config.env != \'production\' %}\\r\\n\\r\\n{# Disallow access to everything when NOT in production #}\\r\\nUser-agent: *\\r\\nDisallow: /\\r\\n\\r\\n{% else %}\\r\\n\\r\\n{# Disallow access to cpresources/ when live #}\\r\\nUser-agent: *\\r\\nDisallow: /cpresources/\\r\\n\\r\\n{% endif %}\"'),('plugins.seo.settings.sitemapLimit','\"1000\"'),('plugins.seo.settings.sitemapName','\"sitemap\"'),('plugins.seo.settings.socialImage','\"\"'),('plugins.seo.settings.title.0.__assoc__.0.0','\"key\"'),('plugins.seo.settings.title.0.__assoc__.0.1','\"1\"'),('plugins.seo.settings.title.0.__assoc__.1.0','\"locked\"'),('plugins.seo.settings.title.0.__assoc__.1.1','\"0\"'),('plugins.seo.settings.title.0.__assoc__.2.0','\"template\"'),('plugins.seo.settings.title.0.__assoc__.2.1','\"{title}\"'),('plugins.seo.settings.title.1.__assoc__.0.0','\"key\"'),('plugins.seo.settings.title.1.__assoc__.0.1','\"2\"'),('plugins.seo.settings.title.1.__assoc__.1.0','\"locked\"'),('plugins.seo.settings.title.1.__assoc__.1.1','\"1\"'),('plugins.seo.settings.title.1.__assoc__.2.0','\"template\"'),('plugins.seo.settings.title.1.__assoc__.2.1','\" - {{ systemName }}\"'),('plugins.seo.settings.titleSuffix','null'),('plugins.seo.settings.twitterHandle','\"\"'),('plugins.vite.edition','\"standard\"'),('plugins.vite.enabled','true'),('plugins.vite.schemaVersion','\"1.0.0\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.defaultPlacement','\"end\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.enableVersioning','true'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.entryTypes.0','\"d7e8d0bc-8052-499d-99b8-d622687dfee7\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.handle','\"home\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.maxAuthors','1'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.name','\"Home\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.previewTargets.0.__assoc__.1.0','\"refresh\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.previewTargets.0.__assoc__.1.1','\"1\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.previewTargets.0.__assoc__.2.0','\"urlFormat\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.previewTargets.0.__assoc__.2.1','\"{url}\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.propagationMethod','\"all\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.enabledByDefault','true'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.hasUrls','true'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.template','\"_pages/singles/home.twig\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.uriFormat','\"__home__\"'),('sections.5b185af0-6204-4ae7-8d25-bf9ef8208ad0.type','\"single\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.defaultPlacement','\"beginning\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.enableVersioning','true'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.entryTypes.0.uid','\"d7e8d0bc-8052-499d-99b8-d622687dfee7\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.handle','\"pages\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.maxAuthors','1'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.name','\"Extra Pages\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.propagationMethod','\"all\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.enabledByDefault','true'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.hasUrls','true'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.template','\"_pages/entry.twig\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.siteSettings.e1acd264-0533-4dd7-8cfa-183423e1c25e.uriFormat','\"{slug}\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.structure.maxLevels','3'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.structure.uid','\"7ddf6c3b-101c-4f71-8d66-e6b989227b38\"'),('sections.eb0d0935-3bc1-4cf1-86d9-275a753716de.type','\"structure\"'),('siteGroups.8ec97a19-2e28-4350-b8a9-78fc2b8a06e2.name','\"craft-boilerplate\"'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.enabled','true'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.handle','\"default\"'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.hasUrls','true'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.language','\"en-US\"'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.name','\"craft-boilerplate\"'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.primary','true'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.siteGroup','\"8ec97a19-2e28-4350-b8a9-78fc2b8a06e2\"'),('sites.e1acd264-0533-4dd7-8cfa-183423e1c25e.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"craft-boilerplate\"'),('system.retryDuration','null'),('system.schemaVersion','\"5.7.0.3\"'),('system.timeZone','\"Europe/Brussels\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elementCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.autocapitalize','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.autocomplete','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.autocorrect','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.class','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.dateAdded','\"2024-12-20T05:46:46-08:00\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.disabled','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.elementCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.id','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.includeInCards','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.inputType','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.instructions','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.label','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.max','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.min','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.name','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.orientation','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.placeholder','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.providesThumbs','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.readonly','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.requirable','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.size','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.step','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.tip','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.title','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\users\\\\UsernameField\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.uid','\"433a680f-c6cb-4072-80b7-1c901451344d\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.userCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.warning','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.0.width','100'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.attribute','\"fullName\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.autocapitalize','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.autocomplete','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.autocorrect','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.class','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.dateAdded','\"2024-12-20T05:46:46-08:00\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.disabled','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.elementCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.id','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.includeInCards','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.inputType','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.instructions','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.label','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.max','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.min','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.name','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.orientation','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.placeholder','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.providesThumbs','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.readonly','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.requirable','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.required','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.size','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.step','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.tip','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.title','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\users\\\\FullNameField\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.uid','\"d2949d0d-5d96-4eb9-930d-ebdb17dd34ea\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.userCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.warning','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.1.width','100'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.dateAdded','\"2024-12-20T05:46:46-08:00\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.elementCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.id','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.includeInCards','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.instructions','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.label','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.orientation','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.providesThumbs','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.requirable','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.tip','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\users\\\\PhotoField\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.uid','\"60803264-ac3d-40f0-a8ec-5c37c0c46c84\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.userCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.warning','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.2.width','100'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.autocapitalize','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.autocomplete','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.autocorrect','true'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.class','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.dateAdded','\"2024-12-20T05:46:46-08:00\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.disabled','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.elementCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.id','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.includeInCards','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.inputType','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.instructions','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.label','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.max','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.min','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.name','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.orientation','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.placeholder','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.providesThumbs','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.readonly','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.requirable','false'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.size','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.step','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.tip','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.title','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\users\\\\EmailField\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.uid','\"d2fb4148-f29c-4136-955f-3a28f2cd6278\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.userCondition','null'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.elements.3.width','100'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.name','\"Content\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.uid','\"5bfc6594-60f5-45d3-992b-f2d2f293671d\"'),('users.fieldLayouts.79259cd3-5e49-4453-b235-b34954a6c20e.tabs.0.userCondition','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.altTranslationKeyFormat','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.altTranslationMethod','\"none\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elementCondition','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.autocapitalize','true'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.autocomplete','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.autocorrect','true'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.class','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.dateAdded','\"2024-10-11T14:18:52+00:00\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.disabled','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.elementCondition','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.id','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.includeInCards','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.inputType','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.instructions','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.label','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.max','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.min','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.name','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.orientation','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.placeholder','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.providesThumbs','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.readonly','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.requirable','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.size','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.step','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.tip','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.title','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.uid','\"f568f977-c63e-4a3b-acab-b42e920cd68d\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.userCondition','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.warning','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.0.width','100'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.attribute','\"alt\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.class','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.cols','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.dateAdded','\"2024-10-11T14:22:07+00:00\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.disabled','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.elementCondition','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.id','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.includeInCards','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.instructions','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.label','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.name','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.orientation','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.placeholder','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.providesThumbs','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.readonly','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.requirable','true'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.required','false'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.rows','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.tip','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.title','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.uid','\"43435a90-40d6-48d8-aef7-d547ca4f7ecf\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.userCondition','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.warning','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.elements.1.width','100'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.name','\"Content\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.uid','\"abe32ab9-b13c-4572-8cbf-5d6cdaed2454\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fieldLayouts.18d8e1db-5acd-48b5-b997-d2cbbe681f03.tabs.0.userCondition','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.fs','\"publicFilesystem\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.handle','\"uploadsField\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.name','\"uploads\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.sortOrder','1'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.subpath','\"\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.titleTranslationKeyFormat','null'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.titleTranslationMethod','\"site\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.transformFs','\"\"'),('volumes.78f386d8-ccbe-4fa9-b24b-f527005175e6.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `relations` VALUES (2,17,21,1,4,1,'2024-11-22 22:26:32','2024-11-22 22:26:32','ee64a838-0476-46ff-833c-dde9dc7b79b7'),(3,17,24,1,4,1,'2024-11-22 22:26:32','2024-11-22 22:26:32','b6c63d24-3e8a-483f-8314-e057528e445e'),(5,17,28,1,4,1,'2024-11-22 22:39:03','2024-11-22 22:39:03','4d904854-8582-4a5f-902d-4a4d0c105e06'),(6,17,31,1,4,1,'2024-11-22 22:39:03','2024-11-22 22:39:03','0982de6e-3511-4955-b143-bc1a77e6d1f7'),(8,22,70,1,4,1,'2024-12-20 15:41:13','2024-12-20 15:41:13','99daf0ca-cdda-4295-a15d-a8bbc7cb86c5'),(9,22,73,1,4,1,'2024-12-20 15:41:13','2024-12-20 15:41:13','2aec99e9-15dc-4a6a-acb9-fe976a9ab8ad'),(10,22,74,1,4,1,'2024-12-20 15:57:24','2024-12-20 15:57:24','4b134071-5f60-4f45-8de7-fbda0aca5de8'),(11,22,75,1,4,1,'2024-12-20 15:57:50','2024-12-20 15:57:50','23eafc08-cc9d-4fa6-8bae-205af2a06aba'),(12,22,76,1,4,1,'2024-12-20 15:58:10','2024-12-20 15:58:10','8ab4ea91-63a7-4518-9594-2cca3c9ecc50');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,4,1,1,NULL),(2,4,1,2,NULL),(3,4,1,3,NULL),(4,4,1,4,'Applied “Draft 1”'),(5,15,1,1,NULL),(6,4,1,5,'Applied “Draft 1”'),(7,15,1,2,NULL),(8,21,1,1,NULL),(9,4,1,6,'Applied “Draft 1”'),(10,15,1,3,NULL),(11,28,1,1,NULL),(12,4,1,7,'Applied “Draft 1”'),(13,4,1,8,'Applied “Draft 1”'),(14,36,1,1,NULL),(15,4,1,9,'Applied “Draft 1”'),(16,36,1,2,NULL),(17,4,1,10,'Applied “Draft 1”'),(18,36,1,3,NULL),(19,4,1,11,'Applied “Draft 1”'),(20,36,1,4,NULL),(21,4,1,12,'Applied “Draft 1”'),(22,36,1,5,NULL),(23,4,1,13,'Applied “Draft 1”'),(24,36,1,6,NULL),(25,4,1,14,'Applied “Draft 1”'),(26,36,1,7,NULL),(27,4,1,15,'Applied “Draft 1”'),(28,36,1,8,NULL),(29,4,1,16,'Applied “Draft 1”'),(30,36,1,9,NULL),(31,70,1,1,NULL),(32,77,1,1,''),(33,79,1,1,''),(34,81,1,1,''),(35,4,1,17,'Applied “Draft 1”'),(36,36,1,10,NULL),(37,4,1,18,''),(38,4,1,19,'Applied “Draft 1”'),(39,4,1,20,''),(40,4,1,21,'Applied “Draft 1”'),(41,95,1,1,NULL),(42,4,1,22,''),(43,4,1,23,''),(44,4,1,24,'Applied “Draft 1”'),(45,95,1,2,NULL),(46,4,1,25,''),(47,4,1,26,'');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' web digitalastronaut be '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' digitalastronaut dev '),(2,'slug',0,1,''),(3,'slug',0,1,''),(4,'field',12,1,' this is a heading 2 this is a heading 3 this is a heading 4 this is a heading 5 this is a heading 6 paragraphs lorem ipsum dolor sit amet consectetur adipisicing elit nisi dolor dignissimos quaerat quod quasi sed minima praesentium beatae odit quidem esse fuga impedit quia unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque accusantium hic laboriosam vero vel corrupti perspiciatis aperiam perferendis dolores ut cupiditate ipsa magni labore digital astronaut lorem ipsum dolor sit amet consectetur adipisicing elit illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente pariatur ea similique nam ipsam itaque quos porro minus sequi tenetur officiis optio expedita voluptate est earum ex tenetur id nobis architecto ipsam cum fuga voluptates quasi adipisci aspernatur odio delectus molestiae pariatur eaque eos hic velit quis similique dolorum voluptas unde id unordered list list item list item list item ordered list ordered list item ordered list item ordered list item ordered list item block quote pariatur ea similique nam ipsam itaque quos porro minus sequi tenetur officiis optio hic velit quis similique dolorum voluptas unde id tables firstname lastname phone number e mailaddress country john doe 32 123 45 67 89 johndoe gmail com belgium peter pingpong 32 111 22 33 44 peterpingpong hotmail com frankrijk '),(4,'slug',0,1,' home '),(4,'title',0,1,' home '),(8,'slug',0,1,' temp vrhawgbayppwysuxxzqxfcgaysevlawfqkhm '),(8,'title',0,1,''),(9,'slug',0,1,' temp hedusacfxjvtdemjutkcbwllbwftmarwzmsx '),(9,'title',0,1,''),(10,'slug',0,1,' temp rucukrqhglvxrqldmzoclpdyfvpmvlkajdhs '),(10,'title',0,1,''),(15,'field',3,1,' lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum '),(15,'field',13,1,' test title '),(15,'field',18,1,' https craft boilerplate ddev site https craft boilerplate ddev site '),(15,'slug',0,1,' temp jqzhbvqvdnhhvabixqsoxumltfomqctslpgf '),(15,'title',0,1,''),(21,'field',17,1,' https craft boilerplate ddev site '),(21,'slug',0,1,' temp cbjkdgxisfzqiukkfhnhsspdgeinljvxnmfs '),(21,'title',0,1,''),(28,'field',17,1,' https craft boilerplate ddev site '),(28,'slug',0,1,' temp irzzmbpgenckudqsskbpgzwwrzsjkdlxygrb '),(28,'title',0,1,''),(36,'field',3,1,' this is a heading 2 this is a heading 3 this is a heading 4 this is a heading 5 this is a heading 6 paragraphs lorem ipsum dolor sit amet consectetur adipisicing elit nisi dolor dignissimos quaerat quod quasi sed minima praesentium beatae odit quidem esse fuga impedit quia unde minus assumenda nesciunt laboriosam recusandae ullam ducimus dolore quos neque accusantium hic laboriosam vero vel corrupti perspiciatis aperiam perferendis dolores ut cupiditate ipsa magni labore digital astronaut lorem ipsum dolor sit amet consectetur adipisicing elit illo nesciunt vel obcaecati sint voluptatem animi quos quis a officiis reiciendis minus tempore beatae porro dolor repellendus magnam voluptates velit tempora praesentium maxime laboriosam dicta amet iusto sapiente pariatur ea similique nam ipsam itaque quos porro minus sequi tenetur officiis optio expedita voluptate est earum ex tenetur id nobis architecto ipsam cum fuga voluptates quasi adipisci aspernatur odio delectus molestiae pariatur eaque eos hic velit quis similique dolorum voluptas unde id unordered list list item list item list item ordered list ordered list item ordered list item ordered list item ordered list item block quote pariatur ea similique nam ipsam itaque quos porro minus sequi tenetur officiis optio hic velit quis similique dolorum voluptas unde id tables firstname lastname phone number e mailaddress country john doe 32 123 45 67 89 johndoe gmail com belgium peter pingpong 32 111 22 33 44 peterpingpong hotmail com frankrijk '),(36,'slug',0,1,' temp ypjmaeikehqiycnefzlwhnifkkyctkgqjydl '),(36,'title',0,1,''),(70,'field',2,1,' test button '),(70,'field',22,1,' https craft boilerplate ddev site '),(70,'slug',0,1,' temp rahjrfwznkwfhzqutlhjzoekocfeontlzfqc '),(70,'title',0,1,''),(74,'field',2,1,' home '),(74,'field',19,1,' https craft boilerplate ddev site sub link 1 https craft boilerplate ddev site sub link 2 '),(74,'field',22,1,' https craft boilerplate ddev site '),(74,'slug',0,1,' temp bdmigfcmkwmzwqgwtbguvmdiwhcsrumbaucr '),(74,'title',0,1,''),(75,'field',2,1,' sub link 1 '),(75,'field',22,1,' https craft boilerplate ddev site '),(75,'slug',0,1,' temp ufignruyyxvhoksfplqehalzjhkebytqqdne '),(75,'title',0,1,''),(76,'field',2,1,' sub link 2 '),(76,'field',22,1,' https craft boilerplate ddev site '),(76,'slug',0,1,' temp rgieumrwftbxkgnakrexgmlgucwcqeuuxspg '),(76,'title',0,1,''),(77,'field',1,1,' privacy policy craft boilerplate '),(77,'slug',0,1,' privacy policy '),(77,'title',0,1,' privacy policy '),(79,'field',1,1,' terms of service craft boilerplate '),(79,'slug',0,1,' terms of service '),(79,'title',0,1,' terms of service '),(81,'field',1,1,' cookie policy craft boilerplate '),(81,'slug',0,1,' cookie policy '),(81,'title',0,1,' cookie policy '),(87,'alt',0,1,''),(87,'extension',0,1,' jpg '),(87,'filename',0,1,' person jpg '),(87,'kind',0,1,' image '),(87,'slug',0,1,''),(87,'title',0,1,' person '),(95,'slug',0,1,' temp ztopivzawpazdxmkwevmkpazsxjzrlfoywsz '),(95,'title',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindexqueue`
--

LOCK TABLES `searchindexqueue` WRITE;
/*!40000 ALTER TABLE `searchindexqueue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `searchindexqueue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindexqueue_fields`
--

LOCK TABLES `searchindexqueue_fields` WRITE;
/*!40000 ALTER TABLE `searchindexqueue_fields` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `searchindexqueue_fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-11 15:04:45','2024-10-11 15:04:45',NULL,'5b185af0-6204-4ae7-8d25-bf9ef8208ad0'),(2,1,'Extra Pages','pages','structure',1,1,'all','beginning','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-10-11 15:05:34','2025-05-26 09:24:58',NULL,'eb0d0935-3bc1-4cf1-86d9-275a753716de');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_entrytypes` VALUES (1,3,1,NULL,NULL),(2,3,1,NULL,NULL);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','_pages/singles/home.twig',1,'2024-10-11 15:04:45','2024-10-11 15:05:55','dc041da3-0fdc-4274-934f-9353ce644eca'),(2,2,1,1,'{slug}','_pages/entry.twig',1,'2024-10-11 15:05:34','2025-01-03 12:58:53','9d6458ee-b80a-4f63-afdc-1d8339e3f511');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seo_redirects`
--

LOCK TABLES `seo_redirects` WRITE;
/*!40000 ALTER TABLE `seo_redirects` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `seo_redirects` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seo_sitemap`
--

LOCK TABLES `seo_sitemap` WRITE;
/*!40000 ALTER TABLE `seo_sitemap` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `seo_sitemap` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'craft-boilerplate','2024-10-11 09:30:43','2024-10-11 09:30:43',NULL,'8ec97a19-2e28-4350-b8a9-78fc2b8a06e2');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'true','craft-boilerplate','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-10-11 09:30:43','2024-10-11 09:30:43',NULL,'e1acd264-0533-4dd7-8cfa-183423e1c25e');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sso_identities`
--

LOCK TABLES `sso_identities` WRITE;
/*!40000 ALTER TABLE `sso_identities` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sso_identities` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,8,0,'2025-01-03 12:56:46','2025-01-03 13:00:35','50409cd4-dad7-4ff1-a4d0-ea4f6cde31e5'),(2,1,77,1,4,5,1,'2025-01-03 12:56:46','2025-01-03 13:00:35','cfd4ce28-1ae9-4f4e-be97-bc218a8eb2ee'),(3,1,79,1,2,3,1,'2025-01-03 13:00:12','2025-01-03 13:00:35','c233371b-921b-4a25-a4a3-91c24718b912'),(4,1,81,1,6,7,1,'2025-01-03 13:00:27','2025-01-03 13:00:35','b2018cc3-0451-4b4a-9ad8-28755bcd2d4c');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,3,'2024-10-11 15:05:34','2024-10-11 15:05:34',NULL,'7ddf6c3b-101c-4f71-8d66-e6b989227b38');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-US\", \"showFieldHandles\": true}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,NULL,1,0,0,0,1,'digitalastronaut.dev',NULL,NULL,NULL,'web@digitalastronaut.be','$2y$13$FkcTXP5TujEcCZQr1yfGKeqTRjnbWhHaiksaN4.oIGm6Ia9k0t.Li','2025-06-17 07:56:32',NULL,NULL,NULL,'2025-06-17 06:38:46',NULL,1,NULL,NULL,NULL,0,'2025-06-17 07:55:21','2024-10-11 09:30:44','2025-06-17 07:56:32');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'uploads','','2024-10-11 14:22:07','2024-10-11 14:22:07','b8e2e7d6-8385-4fda-bf80-1700de1664a6'),(2,NULL,NULL,'Temporary Uploads',NULL,'2024-10-11 14:31:39','2024-10-11 14:31:39','e77250c7-1a67-4828-9c25-9c9069c82ea5'),(3,2,NULL,'user_1','user_1/','2024-10-11 14:31:39','2024-10-11 14:31:39','1884454e-1c9f-4a1d-baec-392162973dc6');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,1,'uploads','uploadsField','publicFilesystem','','','','site',NULL,'none',NULL,1,'2024-10-11 14:22:07','2024-10-11 14:22:07',NULL,'78f386d8-ccbe-4fa9-b24b-f527005175e6');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-10-11 11:10:19','2024-10-11 11:10:19','f9330940-a67e-4333-a993-b52a2f3b81bb'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-10-11 11:10:19','2024-10-11 11:10:19','22b98023-5628-4c46-b1db-f10037696d70'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-10-11 11:10:19','2024-10-11 11:10:19','7b207a84-a340-4939-8a18-3b1611be0980'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-10-11 11:10:19','2024-10-11 11:10:19','e238ff06-3050-4e17-a830-e6603bef8da3');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-17 10:17:24
